import { jsx, jsxs } from 'react/jsx-runtime';
import styled from '@emotion/styled';
import { b as createAstro, c as createComponent, d as addAttribute, a as renderTemplate, r as renderComponent, e as renderHead, f as renderSlot } from './astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { css, keyframes, Global } from '@emotion/react';
import { useEffect, useState, useRef } from 'react';
import 'clsx';
import react from '@vitejs/plugin-react';
import { version } from 'react-dom';
import CompressionPlugin from 'vite-plugin-compression';
import path, { resolve, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { z, ZodError } from 'zod';
import { EnumChangefreq, SitemapAndIndexStream, SitemapStream, SitemapIndexStream } from 'sitemap';
import { createWriteStream } from 'node:fs';
import { mkdir } from 'node:fs/promises';
import { Readable, pipeline } from 'node:stream';
import { promisify } from 'node:util';
import replace from 'stream-replace-string';

const Breakpoints = {
  base: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1440,
  xxxl: 1920
};
const MediaQuery = {
  /**
   *
   * @param breakpoint MediaQuery.min("md")
   * @returns @media example: (min-width: 768px)
   */
  min: (breakpoint) => `@media (min-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param breakpoint MediaQuery.max("lg")
   * @returns @media example: (max-width: 991px)
   */
  max: (breakpoint) => `@media (max-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param minBreakpoint MediaQuery.between("md", "lg")
   * @returns @media example: (min-width: 768px) and (max-width: 991px)
   */
  between: (minBreakpoint, maxBreakpoint) => `@media (min-width: ${Breakpoints[minBreakpoint]}px) and (max-width: ${Breakpoints[maxBreakpoint]}px)`
};

const StyledContainer = styled.div`
    margin: 0 auto;
    padding: 10px;
    width: 100%;
    margin-top: -43px;

    max-width: 540px;

    ${MediaQuery.between("md", "lg")} {
        max-width: 720px;
    }

    ${MediaQuery.between("lg", "xl")} {
        max-width: 960px;
        padding: 40px;
    }

    ${MediaQuery.between("xl", "xxl")} {
        max-width: 1140px;
        padding: 40px;
    }

    ${MediaQuery.min("xxl")} {
        max-width: 1320px;
        padding: 40px;
    }
`;

const Container = ({ children, ...rest }) => {
  if (!children) {
    return null;
  }
  return /* @__PURE__ */ jsx(StyledContainer, { ...rest, children });
};

const Colors = {
  white: "#FFFFFF",
  dark: "#101118",
  darkLighter: "#20222e"
};
const ThemeVar = css`
    :root {
        --primary: ${Colors.white};
        --secondary: ${Colors.darkLighter};
        --tertiary: ${Colors.dark};
    }
`;
const Theme = {
  primary: "var(--primary)",
  secondary: "var(--secondary)",
  tertiary: "var(--tertiary)"
};

const RobotoBlack = "/_astro/Roboto-Black.tBYbbWl-.woff2";

const RobotoBlackItalic = "/_astro/Roboto-BlackItalic.CxCOE_MU.woff2";

const RobotoBold = "/_astro/Roboto-Bold.OBUL28o9.woff2";

const RobotoBoldItalic = "/_astro/Roboto-BoldItalic.Bbs8lVH2.woff2";

const RobotoItalic = "/_astro/Roboto-Italic.0KLjOP-5.woff2";

const RobotoLight = "/_astro/Roboto-Light.-TzFADkf.woff2";

const RobotoLightItalic = "/_astro/Roboto-LightItalic.DuFP9W7P.woff2";

const RobotoMedium = "/_astro/Roboto-Medium.DRylU_ql.woff2";

const RobotoMediumItalic = "/_astro/Roboto-MediumItalic.CPqftbAj.woff2";

const RobotoRegular = "/_astro/Roboto-Regular.CjbfJjO0.woff2";

const RobotoThin = "/_astro/Roboto-Thin.Df4ydPom.woff2";

const RobotoThinItalic = "/_astro/Roboto-ThinItalic.CI9JpB2v.woff2";

var Fonts = /* @__PURE__ */ ((Fonts2) => {
  Fonts2["primary"] = `"Roboto", sans-serif`;
  return Fonts2;
})(Fonts || {});
const FontFace = css`
    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 100;
        src: url(${RobotoThin}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 300;
        src: url(${RobotoLight}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 400;
        src: url(${RobotoRegular}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 500;
        src: url(${RobotoMedium}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 700;
        src: url(${RobotoBold}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 900;
        src: url(${RobotoBlack}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    // italic
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 100;
        src: url(${RobotoThinItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 300;
        src: url(${RobotoLightItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 400;
        src: url(${RobotoItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 500;
        src: url(${RobotoMediumItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 700;
        src: url(${RobotoBoldItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 900;
        src: url(${RobotoBlackItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
`;

const NormalizeCSS = css`
    ${FontFace};
    ${ThemeVar};

    :root {
        color-scheme: light only;
    }

    body,
    html {
        font-family: ${Fonts.primary};
        font-weight: 400;
        font-size: 16px;
        line-height: 1.5;
    }

    * {
        box-sizing: border-box;
    }

    html {
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
    }

    body {
        margin: 0;

        color: ${Theme.tertiary};
        background: ${Theme.primary};
        position: relative;

        &:before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: ${Theme.secondary};
            z-index: 20;
            transition: transform 0.5s;
            transition-delay: 0.2s;
        }

        &::-webkit-scrollbar {
            width: 8px;
            background: ${Theme.secondary};
        }

        &::-webkit-scrollbar-track {
            box-shadow: inset 0 0 6px rgba(0, 0, 0, 1);
        }

        &::-webkit-scrollbar-thumb {
            background-color: #7b7b7bff;
            border-radius: 5px;
        }

        &.hide-overflow {
            &:before {
                transform: translateY(-100%);
            }
        }
    }

    main {
        display: block;
    }

    a {
        background-color: transparent;
    }

    abbr[title] {
        border-bottom: none;
        text-decoration: underline;
        text-decoration: underline dotted;
    }

    img {
        border-style: none;
        object-fit: cover;
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-family: inherit; /* 1 */
        font-size: 100%; /* 1 */
        line-height: 1.15; /* 1 */
        margin: 0; /* 2 */
    }

    button,
    [type="button"],
    [type="reset"],
    [type="submit"] {
        -webkit-appearance: button;
    }

    button::-moz-focus-inner,
    [type="button"]::-moz-focus-inner,
    [type="reset"]::-moz-focus-inner,
    [type="submit"]::-moz-focus-inner {
        border-style: none;
        padding: 0;
    }

    button {
        padding: 0;
    }

    figure {
        margin: 0;
        line-height: 0;
    }

    strong {
        font-weight: 700;
    }

    a {
        text-decoration: none;
        color: inherit;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        margin: 0 0 30px;

        &:last-child {
            margin: 0;
        }
    }

    h1 {
        font-size: 50px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
        }
    }

    h2 {
        font-size: 45px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 35px;
        }
    }

    h3 {
        font-size: 35px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 30px;
        }
    }

    h4 {
        font-size: 25px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 25px;
        }
    }

    h5 {
        font-size: 20px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
        }
    }

    h6 {
        font-size: 18px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 15px;
        }
    }

    p {
        margin: 0 0 10px;
        font-size: 16px;
        line-height: 25px;
        letter-spacing: 1px;
        color: ${Theme.tertiary};

        &:last-child {
            margin: 0;
        }
    }

    .page-404 {
        background-color: ${Theme.secondary};
        height: 100dvh;
        color: ${Theme.primary};

        p {
            color: ${Theme.primary};
        }
    }
`;

const PreviewPng = new Proxy({"src":"/_astro/preview.DZ9dn6Jb.webp","width":1326,"height":754,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/preview.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/preview.webp");
							return target[name];
						}
					});

const HeroImg = new Proxy({"src":"/_astro/hero-img.DA60lgOJ.webp","width":612,"height":408,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/hero-img.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/hero-img.webp");
							return target[name];
						}
					});

const Logo$1 = new Proxy({"src":"/_astro/logo.BzcHXK2T.webp","width":100,"height":100,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/logo.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/logo.webp");
							return target[name];
						}
					});

const HeroSlider = new Proxy({"src":"/_astro/hero-slider.DIYQ3zvp.webp","width":1170,"height":780,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/hero-slider.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/hero-slider.webp");
							return target[name];
						}
					});

const HeroSlider1Preview = new Proxy({"src":"/_astro/hero-slider-01-preview.BgOqr3Ds.webp","width":3840,"height":2160,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/hero-slider-01-preview.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/hero-slider-01-preview.webp");
							return target[name];
						}
					});

const HeroSlider2Preview = new Proxy({"src":"/_astro/hero-slider-02-preview.Cyuy4xXQ.webp","width":3840,"height":2160,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/hero-slider-02-preview.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/hero-slider-02-preview.webp");
							return target[name];
						}
					});

const HeroSlider3Preview = new Proxy({"src":"/_astro/hero-slider-03-preview.DgTPUFYE.webp","width":3840,"height":2160,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/hero-slider-03-preview.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/hero-slider-03-preview.webp");
							return target[name];
						}
					});

const InfiniteImg1 = new Proxy({"src":"/_astro/infinite-img-1.C1BCkNiX.webp","width":1024,"height":768,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/infinite-img-1.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/infinite-img-1.webp");
							return target[name];
						}
					});

const InfiniteImg2 = new Proxy({"src":"/_astro/infinite-img-2.BXtCDM2h.webp","width":1024,"height":768,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/images/infinite-img-2.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/images/infinite-img-2.webp");
							return target[name];
						}
					});

styled.div`
    position: relative;
    z-index: 3;

    a {
        font-size: 35px;
        line-height: 30px;
        font-weight: 700;
        display: inline-flex;
        position: relative;

        span {
            &:after {
                content: "";
                position: absolute;
                bottom: -5px;
                left: 0;
                width: 25%;
                height: 3px;
                background-color: ${Theme.primary};
                z-index: 1;
                transition: width 0.2s linear;
            }
        }

        &:hover span:after {
            width: 100%;
        }

        img {
            height: 50px;
            width: 63px;
            object-fit: contain;
        }
    }
`;
const LogoTextStyled = styled.div`
    position: relative;
    z-index: 3;

    a {
        font-size: 35px;
        line-height: 30px;
        font-weight: 700;
        display: inline-flex;
        position: relative;

        span {
            color: ${Theme.primary};
            letter-spacing: 5px;
            &:after {
                content: "";
                position: absolute;
                bottom: -5px;
                left: 0;
                width: 25%;
                height: 3px;
                background-color: ${Theme.primary};
                z-index: 1;
                transition: width 0.2s linear;
            }
        }

        &:hover span:after {
            width: 100%;
        }
    }
`;

const Logo = () => {
  return /* @__PURE__ */ jsx(LogoTextStyled, { children: /* @__PURE__ */ jsx("a", { href: "/", children: /* @__PURE__ */ jsx("span", { children: "luxion" }) }) });
};

const FadeInStyled = styled.div`
    opacity: 0.001;
    transform: translateY(20px);
    transition: opacity 0.5s, transform 0.5s;

    &.visible {
        opacity: 1;
        transform: translateY(0);
    }
`;
const FadeInKeyframes = keyframes`
    from {
        transform: translateY(50px);
        opacity: 0.01;
    }

    to {
        transform: translateY(0);
        opacity: 1;
    }
`;

const HeaderStyled = styled.header`
    width: 100%;

    padding: 20px 0;

    display: flex;

    justify-content: space-between;
    align-items: center;

    gap: 40px;

    position: fixed;
    top: 0;
    left: 0;
    z-index: 10;

    animation: ${FadeInKeyframes} 1s;
    animation-delay: 0.4s;
    transition: background 0.5s;

    &.scrolled {
        background: rgba(0, 0, 0, 0.8);
    }
`;
const ContainerStyled = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    padding: 0 40px;

    ${MediaQuery.max("lg")} {
        padding: 0 20px;
    }
`;

const NavigationStyled = styled.div`
    display: flex;
    gap: 50px;

    ${MediaQuery.max("xl")} {
        gap: 20px;
    }
`;
const NavigationListWrapper = styled.nav`
    display: flex;
    align-items: center;
    justify-content: center;

    ${MediaQuery.max("lg")} {
        position: fixed;
        top: 0;
        right: -100%;

        background: ${Theme.secondary};
        height: 100dvh;
        z-index: 2;
        transform: translateX(100%);
        transition: transform 0.3s linear, right 0.7s;
        padding-top: 85px;

        width: clamp(300px, 80%, 300px);

        ${({ $isOpen }) => $isOpen && css`
                right: 0;
                transform: translateX(0);
            `};
    }
`;
const NavigationList = styled.ul`
    padding: 0;
    margin: 0;
    list-style-type: none;
    display: flex;

    ${MediaQuery.min("lg")} {
        gap: 20px;
        align-items: center;
        justify-content: center;
    }

    ${MediaQuery.max("lg")} {
        gap: 10px;
        padding: 20px 10px 53px;
        overflow: auto;
        width: 100%;
        height: 100%;

        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
    }

    > li a {
        text-decoration: none;
        color: ${Theme.primary};
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        line-height: 25px;
        text-transform: uppercase;
        font-weight: 900;
        letter-spacing: 1px;
        text-shadow: 1px 1px 1px rgba(0, 0, 0, 1);
        padding: 10px;
        border-radius: 5px;
        background-color: transparent;
        cursor: pointer;
        transition: background-color 0.3s, color 0.3s;

        ${MediaQuery.max("lg")} {
            padding: 10px 20px;
        }

        &:hover {
            background-color: ${Theme.primary};
            color: ${Theme.secondary};

            text-shadow: none;
        }

        img {
            margin: 0 15px 0 0;

            max-width: 30px;
            max-height: 30px;

            ${MediaQuery.max("xl")} {
                margin: 0 10px 0 0;
            }
        }
    }
`;
const DropdownContainer = styled.div`
    position: relative;
    display: inline-block;
`;
const DropdownTrigger = styled.div`
    text-decoration: none;
    color: ${Theme.primary};
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    line-height: 25px;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 1px;
    text-shadow: 1px 1px 1px rgba(0, 0, 0, 1);
    padding: 12px 16px;
    border-radius: 8px;
    cursor: pointer;
    position: relative;
    overflow: hidden;

    ${MediaQuery.max("lg")} {
        padding: 12px 20px;
        border: none;
        background: transparent;
        
        &::before {
            display: none;
        }
    }

    &:hover {
        background: linear-gradient(135deg, ${Theme.primary} 0%, rgba(255, 255, 255, 0.9) 100%);
        color: ${Theme.secondary};
        text-shadow: none;
        border-color: ${Theme.primary};
        box-shadow: 0 8px 25px rgba(255, 255, 255, 0.2);
        transform: translateY(-2px);

        &::before {
            left: 100%;
        }

        ${MediaQuery.max("lg")} {
            background: ${Theme.primary};
            transform: none;
            box-shadow: none;
        }

        & span {
            color: ${Theme.secondary} !important;
        }
    }
`;
const DropdownArrow = styled.span`
    margin-left: 10px;
    font-size: 14px;
    font-weight: bold;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    transform: ${({ $isOpen }) => $isOpen ? "rotate(180deg) scale(1.1)" : "rotate(0deg) scale(1)"};
    color: ${({ $isOpen }) => $isOpen ? Theme.primary : "inherit"};
    filter: ${({ $isOpen }) => $isOpen ? "drop-shadow(0 0 3px rgba(255, 255, 255, 0.5))" : "none"};
`;
const DropdownMenu = styled.div`
    position: absolute;
    top: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(145deg, ${Theme.secondary} 0%, rgba(0, 0, 0, 0.95) 100%);
    border-radius: 6px;
    box-shadow: 
        0 20px 40px rgba(0, 0, 0, 0.4),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    opacity: ${({ $isOpen }) => $isOpen ? 1 : 0};
    visibility: ${({ $isOpen }) => $isOpen ? "visible" : "hidden"};
    transform: ${({ $isOpen }) => $isOpen ? "translateX(-50%) translateY(0) scale(1)" : "translateX(-50%) translateY(-15px) scale(0.95)"};
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    min-width: 280px;
    overflow: hidden;

    &::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 50%;
        transform: translateX(-50%);
        width: 0;
        height: 0;
        border-left: 8px solid transparent;
        border-right: 8px solid transparent;
        border-bottom: 8px solid ${Theme.primary};
        z-index: 1001;
    }

    &::after {
        content: '';
        position: absolute;
        top: -6px;
        left: 50%;
        transform: translateX(-50%);
        width: 0;
        height: 0;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        border-bottom: 6px solid ${Theme.secondary};
        z-index: 1002;
    }

    ${MediaQuery.max("lg")} {
        position: static;
        opacity: 1;
        visibility: visible;
        transform: none;
        box-shadow: none;
        border: none;
        background: transparent;
        backdrop-filter: none;
        min-width: auto;
        width: 100%;
        margin-left: 20px;
        border-radius: 0;
        display: ${({ $isOpen }) => $isOpen ? "block" : "none"};

        &::before,
        &::after {
            display: none;
        }
    }
`;
const DropdownItem = styled.a`
    display: block !important;
    padding: 16px 24px !important;
    color: ${Theme.primary} !important;
    text-decoration: none !important;
    font-size: 16px !important;
    font-weight: 500 !important;
    letter-spacing: 0.5px !important;
    position: relative;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    background: transparent !important;
    text-align: left !important;
    justify-content: flex-start !important;
    align-items: flex-start !important;
    text-transform: none !important;
    text-shadow: none !important;
    border-radius: 0 !important;

    &:hover {
        background: linear-gradient(90deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%) !important;
        color: ${Theme.primary} !important;
        padding-left: 32px !important;
        border-left: 3px solid ${Theme.primary};
        box-shadow: 0 4px 15px rgba(255, 255, 255, 0.1);
        
        &::before {
            content: '→';
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: ${Theme.primary};
            font-weight: bold;
            opacity: 1;
            transition: all 0.3s ease;
        }
    }

    &::before {
        content: '';
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        opacity: 0;
        transition: all 0.3s ease;
    }

    &:last-child {
        border-bottom: none;
    }

    &:active {
        transform: translateX(2px) scale(0.98);
    }

    ${MediaQuery.max("lg")} {
        padding: 12px 16px;
        font-size: 16px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);

        &::before,
        &::after {
            display: none;
        }

        &:hover {
            padding-left: 16px;
            transform: none;
            background: rgba(255, 255, 255, 0.1);
        }

        &:active {
            transform: none;
        }
    }
`;

const HamburgerMenuButton = styled.button`
    position: relative;
    z-index: 3;

    background: ${Theme.primary};
    border-radius: 50%;
    cursor: pointer;
    transition: background 0.3s, border-color 0.3s, color 0.3s;
    width: 45px;
    height: 45px;
    border-color: transparent;

    ${MediaQuery.min("lg")} {
        display: none;
    }
`;
const HamburgerMenuButtonLine = styled.span`
    background: ${Theme.secondary};
    position: absolute;
    left: 50%;
    display: block;
    transform: translate(-50%, -50%);
    transition: transform 0.3s, background 0.3s, top 0.3s;
    pointer-events: none;

    width: 50%;
    height: 3px;

    ${MediaQuery.max("lg")} {
        height: 2px;
    }

    ${({ $open }) => $open ? css`
                  transform: translate(-50%, -50%) rotate(45deg);
                  top: 50%;
              ` : css`
                  top: calc(50% - 4px);
              `}

    &:not(:first-of-type) {
        ${({ $open }) => $open ? css`
                      transform: translate(-49%, -50%) rotate(-45deg);
                      top: 50%;
                  ` : css`
                      top: calc(50% + 4px);
                  `}
    }
`;

const Hamburger = ({ state }) => {
  const { open, setOpen } = state;
  const handleMenu = () => {
    setOpen(!open);
  };
  const handleClickOutside = (e) => {
    const target = e.target;
    if (!target.closest("nav") && open && target.tagName !== "BUTTON") {
      setOpen(false);
    }
  };
  useEffect(() => {
    if (!open) return;
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [open]);
  return /* @__PURE__ */ jsxs(
    HamburgerMenuButton,
    {
      $open: open,
      onClick: handleMenu,
      "aria-label": "Menu",
      "aria-expanded": open,
      role: "button",
      tabIndex: 0,
      children: [
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open }),
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open })
      ]
    }
  );
};

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);
  return /* @__PURE__ */ jsxs(NavigationStyled, { children: [
    /* @__PURE__ */ jsx(NavigationListWrapper, { $isOpen: isOpen, children: /* @__PURE__ */ jsxs(NavigationList, { children: [
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/", children: "Inicio" }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
        DropdownContainer,
        {
          onMouseEnter: () => setIsServicesDropdownOpen(true),
          onMouseLeave: () => setIsServicesDropdownOpen(false),
          children: [
            /* @__PURE__ */ jsxs(DropdownTrigger, { children: [
              "Servicios",
              /* @__PURE__ */ jsx(DropdownArrow, { $isOpen: isServicesDropdownOpen, children: "▼" })
            ] }),
            /* @__PURE__ */ jsxs(DropdownMenu, { $isOpen: isServicesDropdownOpen, children: [
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/software-a-medida", children: "Software a medida" }),
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/automatizaciones", children: "Automatizaciones" }),
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/integraciones", children: "Integraciones" }),
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/apps-moviles", children: "Apps Moviles" }),
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/ia-chatbots", children: "IA Chatbots" }),
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/soporte", children: "Soporte" }),
              /* @__PURE__ */ jsx(DropdownItem, { href: "/servicios/sitio-web-express", children: "Sitio web Express" })
            ] })
          ]
        }
      ) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/contacto", children: "Contacto" }) })
    ] }) }),
    /* @__PURE__ */ jsx(
      Hamburger,
      {
        state: {
          open: isOpen,
          setOpen: setIsOpen
        }
      }
    )
  ] });
};

const Header = () => {
  useEffect(() => {
    const header = document.querySelector("header");
    const handleScroll = () => {
      if (window.scrollY > 0) {
        header?.classList.add("scrolled");
      } else {
        header?.classList.remove("scrolled");
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return /* @__PURE__ */ jsx(HeaderStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled, { children: [
    /* @__PURE__ */ jsx(Logo, {}),
    /* @__PURE__ */ jsx(Navigation, {})
  ] }) });
};

function defineConfig(config) {
  return config;
}

function getReactMajorVersion() {
  const matches = /\d+\./.exec(version);
  if (!matches) {
    return NaN;
  }
  return Number(matches[0]);
}
function isUnsupportedVersion(majorVersion) {
  return majorVersion < 17 || majorVersion > 19 || Number.isNaN(majorVersion);
}
const versionsConfig = {
  17: {
    server: "@astrojs/react/server-v17.js",
    client: "@astrojs/react/client-v17.js",
    externals: ["react-dom/server.js", "react-dom/client.js"]
  },
  18: {
    server: "@astrojs/react/server.js",
    client: "@astrojs/react/client.js",
    externals: ["react-dom/server", "react-dom/client"]
  },
  19: {
    server: "@astrojs/react/server.js",
    client: "@astrojs/react/client.js",
    externals: ["react-dom/server", "react-dom/client"]
  }
};

const FAST_REFRESH_PREAMBLE = react.preambleCode;
function getRenderer(reactConfig) {
  return {
    name: "@astrojs/react",
    clientEntrypoint: reactConfig.client,
    serverEntrypoint: reactConfig.server
  };
}
function optionsPlugin(experimentalReactChildren) {
  const virtualModule = "astro:react:opts";
  const virtualModuleId = "\0" + virtualModule;
  return {
    name: "@astrojs/react:opts",
    resolveId(id) {
      if (id === virtualModule) {
        return virtualModuleId;
      }
    },
    load(id) {
      if (id === virtualModuleId) {
        return {
          code: `export default {
						experimentalReactChildren: ${JSON.stringify(experimentalReactChildren)}
					}`
        };
      }
    }
  };
}
function getViteConfiguration({ include, exclude, babel, experimentalReactChildren } = {}, reactConfig) {
  return {
    optimizeDeps: {
      include: [
        reactConfig.client,
        "react",
        "react/jsx-runtime",
        "react/jsx-dev-runtime",
        "react-dom"
      ],
      exclude: [reactConfig.server]
    },
    plugins: [react({ include, exclude, babel }), optionsPlugin(!!experimentalReactChildren)],
    resolve: {
      dedupe: ["react", "react-dom", "react-dom/server"]
    },
    ssr: {
      external: reactConfig.externals,
      noExternal: [
        // These are all needed to get mui to work.
        "@mui/material",
        "@mui/base",
        "@babel/runtime",
        "use-immer",
        "@material-tailwind/react"
      ]
    }
  };
}
function src_default({
  include,
  exclude,
  babel,
  experimentalReactChildren
} = {}) {
  const majorVersion = getReactMajorVersion();
  if (isUnsupportedVersion(majorVersion)) {
    throw new Error(`Unsupported React version: ${majorVersion}.`);
  }
  const versionConfig = versionsConfig[majorVersion];
  return {
    name: "@astrojs/react",
    hooks: {
      "astro:config:setup": ({ command, addRenderer, updateConfig, injectScript }) => {
        addRenderer(getRenderer(versionConfig));
        updateConfig({
          vite: getViteConfiguration(
            { include, exclude, babel, experimentalReactChildren },
            versionConfig
          )
        });
        if (command === "dev") {
          const preamble = FAST_REFRESH_PREAMBLE.replace(`__BASE__`, "/");
          injectScript("before-hydration", preamble);
        }
      }
    }
  };
}

function parseI18nUrl(url, defaultLocale, locales, base) {
  if (!url.startsWith(base)) {
    return void 0;
  }
  let s = url.slice(base.length);
  if (!s || s === "/") {
    return { locale: defaultLocale, path: "/" };
  }
  if (s[0] !== "/") {
    s = "/" + s;
  }
  const locale = s.split("/")[1];
  if (locale in locales) {
    let path = s.slice(1 + locale.length);
    if (!path) {
      path = "/";
    }
    return { locale, path };
  }
  return { locale: defaultLocale, path: s };
}

function generateSitemap(pages, finalSiteUrl, opts) {
  const { changefreq, priority, lastmod: lastmodSrc, i18n } = opts ?? {};
  const urls = [...pages];
  urls.sort((a, b) => a.localeCompare(b, "en", { numeric: true }));
  const lastmod = lastmodSrc?.toISOString();
  const { defaultLocale, locales } = i18n ?? {};
  let getI18nLinks;
  if (defaultLocale && locales) {
    getI18nLinks = createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl);
  }
  const urlData = urls.map((url, i) => ({
    url,
    links: getI18nLinks?.(i),
    lastmod,
    priority,
    changefreq
  }));
  return urlData;
}
function createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl) {
  const parsedI18nUrls = urls.map((url) => parseI18nUrl(url, defaultLocale, locales, finalSiteUrl));
  const i18nPathToLinksCache = /* @__PURE__ */ new Map();
  return (urlIndex) => {
    const i18nUrl = parsedI18nUrls[urlIndex];
    if (!i18nUrl) {
      return void 0;
    }
    const cached = i18nPathToLinksCache.get(i18nUrl.path);
    if (cached) {
      return cached;
    }
    const links = [];
    for (let i = 0; i < parsedI18nUrls.length; i++) {
      const parsed = parsedI18nUrls[i];
      if (parsed?.path === i18nUrl.path) {
        links.push({
          url: urls[i],
          lang: locales[parsed.locale]
        });
      }
    }
    if (links.length <= 1) {
      return void 0;
    }
    i18nPathToLinksCache.set(i18nUrl.path, links);
    return links;
  };
}

const SITEMAP_CONFIG_DEFAULTS = {
  filenameBase: "sitemap",
  entryLimit: 45e3,
  namespaces: {
    news: true,
    xhtml: true,
    image: true,
    video: true
  }
};

const localeKeySchema = z.string().min(1);
const SitemapOptionsSchema = z.object({
  filenameBase: z.string().optional().default(SITEMAP_CONFIG_DEFAULTS.filenameBase),
  filter: z.function().args(z.string()).returns(z.boolean()).optional(),
  customSitemaps: z.string().url().array().optional(),
  customPages: z.string().url().array().optional(),
  canonicalURL: z.string().url().optional(),
  xslURL: z.string().optional(),
  i18n: z.object({
    defaultLocale: localeKeySchema,
    locales: z.record(
      localeKeySchema,
      z.string().min(2).regex(/^[a-zA-Z\-]+$/gm, {
        message: "Only English alphabet symbols and hyphen allowed"
      })
    )
  }).refine((val) => !val || val.locales[val.defaultLocale], {
    message: "`defaultLocale` must exist in `locales` keys"
  }).optional(),
  entryLimit: z.number().nonnegative().optional().default(SITEMAP_CONFIG_DEFAULTS.entryLimit),
  serialize: z.function().args(z.any()).returns(z.any()).optional(),
  changefreq: z.nativeEnum(EnumChangefreq).optional(),
  lastmod: z.date().optional(),
  priority: z.number().min(0).max(1).optional(),
  namespaces: z.object({
    news: z.boolean().optional(),
    xhtml: z.boolean().optional(),
    image: z.boolean().optional(),
    video: z.boolean().optional()
  }).optional().default(SITEMAP_CONFIG_DEFAULTS.namespaces)
}).strict().default(SITEMAP_CONFIG_DEFAULTS);

const validateOptions = (site, opts) => {
  const result = SitemapOptionsSchema.parse(opts);
  z.object({
    site: z.string().optional(),
    // Astro takes care of `site`: how to validate, transform and refine
    canonicalURL: z.string().optional()
    // `canonicalURL` is already validated in prev step
  }).refine((options) => options.site || options.canonicalURL, {
    message: "Required `site` astro.config option or `canonicalURL` integration option"
  }).parse({
    site,
    canonicalURL: result.canonicalURL
  });
  return result;
};

async function writeSitemap({
  filenameBase,
  hostname,
  sitemapHostname = hostname,
  sourceData,
  destinationDir,
  limit = 5e4,
  customSitemaps = [],
  publicBasePath = "./",
  xslURL: xslUrl,
  lastmod,
  namespaces = { news: true, xhtml: true, image: true, video: true }
}, astroConfig) {
  await mkdir(destinationDir, { recursive: true });
  const sitemapAndIndexStream = new SitemapAndIndexStream({
    limit,
    xslUrl,
    getSitemapStream: (i) => {
      const sitemapStream = new SitemapStream({
        hostname,
        xslUrl,
        // Custom namespace handling
        xmlns: {
          news: namespaces?.news !== false,
          xhtml: namespaces?.xhtml !== false,
          image: namespaces?.image !== false,
          video: namespaces?.video !== false
        }
      });
      const path = `./${filenameBase}-${i}.xml`;
      const writePath = resolve(destinationDir, path);
      if (!publicBasePath.endsWith("/")) {
        publicBasePath += "/";
      }
      const publicPath = normalize(publicBasePath + path);
      let stream;
      if (astroConfig.trailingSlash === "never" || astroConfig.build.format === "file") {
        const host = hostname.endsWith("/") ? hostname.slice(0, -1) : hostname;
        const searchStr = `<loc>${host}/</loc>`;
        const replaceStr = `<loc>${host}</loc>`;
        stream = sitemapStream.pipe(replace(searchStr, replaceStr)).pipe(createWriteStream(writePath));
      } else {
        stream = sitemapStream.pipe(createWriteStream(writePath));
      }
      const url = new URL(publicPath, sitemapHostname).toString();
      return [{ url, lastmod }, sitemapStream, stream];
    }
  });
  const src = Readable.from(sourceData);
  const indexPath = resolve(destinationDir, `./${filenameBase}-index.xml`);
  for (const url of customSitemaps) {
    SitemapIndexStream.prototype._transform.call(
      sitemapAndIndexStream,
      { url, lastmod },
      "utf8",
      () => {
      }
    );
  }
  return promisify(pipeline)(src, sitemapAndIndexStream, createWriteStream(indexPath));
}

function formatConfigErrorMessage(err) {
  const errorList = err.issues.map((issue) => ` ${issue.path.join(".")}  ${issue.message + "."}`);
  return errorList.join("\n");
}
const PKG_NAME = "@astrojs/sitemap";
const STATUS_CODE_PAGES = /* @__PURE__ */ new Set(["404", "500"]);
const isStatusCodePage = (locales) => {
  const statusPathNames = new Set(
    locales.flatMap((locale) => [...STATUS_CODE_PAGES].map((page) => `${locale}/${page}`)).concat([...STATUS_CODE_PAGES])
  );
  return (pathname) => {
    if (pathname.endsWith("/")) {
      pathname = pathname.slice(0, -1);
    }
    if (pathname.startsWith("/")) {
      pathname = pathname.slice(1);
    }
    return statusPathNames.has(pathname);
  };
};
const createPlugin = (options) => {
  let config;
  return {
    name: PKG_NAME,
    hooks: {
      "astro:config:done": async ({ config: cfg }) => {
        config = cfg;
      },
      "astro:build:done": async ({ dir, routes, pages, logger }) => {
        try {
          if (!config.site) {
            logger.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          const opts = validateOptions(config.site, options);
          const { filenameBase, filter, customPages, customSitemaps, serialize, entryLimit } = opts;
          const outFile = `${filenameBase}-index.xml`;
          const finalSiteUrl = new URL(config.base, config.site);
          const shouldIgnoreStatus = isStatusCodePage(Object.keys(opts.i18n?.locales ?? {}));
          let pageUrls = pages.filter((p) => !shouldIgnoreStatus(p.pathname)).map((p) => {
            if (p.pathname !== "" && !finalSiteUrl.pathname.endsWith("/"))
              finalSiteUrl.pathname += "/";
            if (p.pathname.startsWith("/")) p.pathname = p.pathname.slice(1);
            const fullPath = finalSiteUrl.pathname + p.pathname;
            return new URL(fullPath, finalSiteUrl).href;
          });
          const routeUrls = routes.reduce((urls, r) => {
            if (r.type !== "page") return urls;
            if (r.pathname) {
              if (shouldIgnoreStatus(r.pathname ?? r.route)) return urls;
              let fullPath = finalSiteUrl.pathname;
              if (fullPath.endsWith("/")) fullPath += r.generate(r.pathname).substring(1);
              else fullPath += r.generate(r.pathname);
              const newUrl = new URL(fullPath, finalSiteUrl).href;
              if (config.trailingSlash === "never") {
                urls.push(newUrl);
              } else if (config.build.format === "directory" && !newUrl.endsWith("/")) {
                urls.push(newUrl + "/");
              } else {
                urls.push(newUrl);
              }
            }
            return urls;
          }, []);
          pageUrls = Array.from(/* @__PURE__ */ new Set([...pageUrls, ...routeUrls, ...customPages ?? []]));
          if (filter) {
            pageUrls = pageUrls.filter(filter);
          }
          if (pageUrls.length === 0) {
            logger.warn(`No pages found!
\`${outFile}\` not created.`);
            return;
          }
          let urlData = generateSitemap(pageUrls, finalSiteUrl.href, opts);
          if (serialize) {
            try {
              const serializedUrls = [];
              for (const item of urlData) {
                const serialized = await Promise.resolve(serialize(item));
                if (serialized) {
                  serializedUrls.push(serialized);
                }
              }
              if (serializedUrls.length === 0) {
                logger.warn("No pages found!");
                return;
              }
              urlData = serializedUrls;
            } catch (err) {
              logger.error(`Error serializing pages
${err.toString()}`);
              return;
            }
          }
          const destDir = fileURLToPath(dir);
          const lastmod = opts.lastmod?.toISOString();
          const xslURL = opts.xslURL ? new URL(opts.xslURL, finalSiteUrl).href : void 0;
          await writeSitemap(
            {
              filenameBase,
              hostname: finalSiteUrl.href,
              destinationDir: destDir,
              publicBasePath: config.base,
              sourceData: urlData,
              limit: entryLimit,
              customSitemaps,
              xslURL,
              lastmod,
              namespaces: opts.namespaces
            },
            config
          );
          logger.info(`\`${outFile}\` created at \`${path.relative(process.cwd(), destDir)}\``);
        } catch (err) {
          if (err instanceof ZodError) {
            logger.warn(formatConfigErrorMessage(err));
          } else {
            throw err;
          }
        }
      }
    }
  };
};
var index_default = createPlugin;

// Update this to your GitHub Pages URL, e.g. https://<username>.github.io/<repo>
const siteUrl = "https://luxiondev.com";

const date = new Date().toISOString();
// https://astro.build/config
defineConfig({
    site: siteUrl + "/",
    output: "static", // Required for GitHub Pages

    integrations: [
        src_default(),
        index_default({
            serialize(item) {
                // Default values for pages
                item.priority = siteUrl + "/" === item.url ? 1.0 : 0.9;
                item.changefreq = "weekly";
                item.lastmod = date;

                // if you want to exclude a page from the sitemap, do it here
                // if (/exclude-from-sitemap/.test(item.url)) {
                //     return undefined;
                // }

                // if any page needs a different priority, changefreq, or lastmod, uncomment the following lines and adjust as needed
                // if (/test-sitemap/.test(item.url)) {
                //     item.changefreq = "daily";
                //     item.lastmod = date;
                //     item.priority = 0.9;
                // }

                // if you want to change priority of all subpages like "/posts/*", you can use:
                // if (/\/posts\//.test(item.url)) {
                //     item.priority = 0.7;
                // }
                return item;
            },
        }),
    ],
    renderers: ["@astrojs/renderer-react"],
    prerender: true,
    vite: {
        plugins: [CompressionPlugin()],
    },
    buildOptions: {
        minify: true,
    },
});

const $$Astro$1 = createAstro("https://luxiondev.com/");
const $$MetaConfig = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MetaConfig;
  const { title, description, preview } = Astro2.props;
  const metaData = {
    keywords: "astro.build, astro, static site, react, webiste templates, website creation, react templates, next.js templates, astro templates, custom website, custom website templates",
    default: {
      url: siteUrl,
      type: "website",
      title,
      description,
      image: preview
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      image: preview,
      domain: siteUrl,
      url: siteUrl
    }
  };
  return renderTemplate`<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><!-- icons --><link rel="icon" type="image/x-icon" href="/favicon.ico"><link rel="apple-touch-icon" sizes="48x48" href="/favicon.ico"><!-- Other meta important things --><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="color-scheme" content="light only"><meta name="keywords"${addAttribute(metaData.keywords, "content")}><meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"><!-- default ones --><meta property="url"${addAttribute(metaData.default.url, "content")}><meta property="type"${addAttribute(metaData.default.type, "content")}><meta property="title"${addAttribute(metaData.default.title, "content")}><meta property="description"${addAttribute(metaData.default.description, "content")}><meta property="image"${addAttribute(metaData.default.image, "content")}><!-- open graph ones --><meta property="og:url"${addAttribute(metaData.default.url, "content")}><meta property="og:type"${addAttribute(metaData.default.type, "content")}><meta property="og:title"${addAttribute(metaData.default.title, "content")}><meta property="og:description"${addAttribute(metaData.default.description, "content")}><meta property="og:image"${addAttribute(metaData.default.image, "content")}><!-- twitter ones --><meta name="twitter:card"${addAttribute(metaData.twitter.card, "content")}><meta name="twitter:title"${addAttribute(metaData.twitter.title, "content")}><meta name="twitter:description"${addAttribute(metaData.twitter.description, "content")}><meta name="twitter:image"${addAttribute(metaData.twitter.image, "content")}><meta property="twitter:domain"${addAttribute(metaData.twitter.domain, "content")}><meta property="twitter:url"${addAttribute(metaData.twitter.url, "content")}>`;
}, "/home/runner/work/website/website/src/layouts/MetaConfig.astro", void 0);

const $$Astro = createAstro("https://luxiondev.com/");
const $$Layout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title, description, overwritePreview } = Astro2.props;
  return renderTemplate`<html lang="en"> <head>${renderComponent($$result, "MetaConfig", $$MetaConfig, { "title": title, "description": description, "preview": overwritePreview ? overwritePreview : PreviewPng.src })}<title>${title}</title>${renderComponent($$result, "Global", Global, { "styles": NormalizeCSS })}${renderHead()}</head> <body> ${renderComponent($$result, "Header", Header, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Header", "client:component-export": "Header" })} ${renderSlot($$result, $$slots["default"])} </body></html>`;
}, "/home/runner/work/website/website/src/layouts/Layout.astro", void 0);

const convertToMilliseconds = (delay) => {
  return Number(delay) || 0;
};
const FadeIn = ({ children, delay = 0 }) => {
  const elementRef = useRef(null);
  const observerRef = useRef(null);
  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;
    if (observerRef.current) {
      observerRef.current.disconnect();
    }
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !entry.target.classList.contains("visible")) {
            const targetElement = entry.target;
            const timeoutId = setTimeout(() => {
              targetElement.classList.add("visible");
            }, convertToMilliseconds(delay));
            observerRef.current?.unobserve(targetElement);
            return () => clearTimeout(timeoutId);
          }
        });
      },
      {
        root: null,
        rootMargin: "0px 0px -10% 0px",
        threshold: 0.1
      }
    );
    observerRef.current.observe(element);
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
        observerRef.current = null;
      }
    };
  }, []);
  return /* @__PURE__ */ jsx(FadeInStyled, { ref: elementRef, children });
};

const IconArrowDown = new Proxy({"src":"/_astro/icon-arrow-down.BDCzw7Ed.svg","width":30,"height":30,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-arrow-down.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-arrow-down.svg");
							return target[name];
						}
					});

const IconArrowCircle = new Proxy({"src":"/_astro/icon-arrow-circle.DUoOPlmj.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-arrow-circle.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-arrow-circle.svg");
							return target[name];
						}
					});

const IconArrowRight = new Proxy({"src":"/_astro/icon-arrow-right.DqPTpFau.svg","width":20,"height":20,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-arrow-right.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-arrow-right.svg");
							return target[name];
						}
					});

const IconFacebook = new Proxy({"src":"/_astro/icon-facebook.CiZt8951.svg","width":15,"height":32,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-facebook.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-facebook.svg");
							return target[name];
						}
					});

const IconInstagram = new Proxy({"src":"/_astro/icon-instagram.BWvvhaKh.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-instagram.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-instagram.svg");
							return target[name];
						}
					});

const IconTwitter = new Proxy({"src":"/_astro/icon-twitter.-eebusCm.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-twitter.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-twitter.svg");
							return target[name];
						}
					});

const IconLinkedIn = new Proxy({"src":"/_astro/icon-linkedin.Cr8d3BTd.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-linkedin.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-linkedin.svg");
							return target[name];
						}
					});

const IconGithub = new Proxy({"src":"/_astro/icon-github.DH9R7T2y.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/website/website/src/static/icons/icon-github.svg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/website/website/src/static/icons/icon-github.svg");
							return target[name];
						}
					});

const icons = {
  arrowDown: IconArrowDown,
  arrowCircle: IconArrowCircle,
  arrowRight: IconArrowRight,
  facebook: IconFacebook,
  instagram: IconInstagram,
  twitter: IconTwitter,
  linkedin: IconLinkedIn,
  github: IconGithub
};
const Icon = ({ alt, iconData, ...rest }) => {
  const icon = icons[iconData];
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: icon.src,
      alt,
      width: icon.width,
      height: icon.height,
      "data-icon": "true",
      ...rest
    }
  );
};

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: ${({ $align }) => $align || "flex-start"};
    margin-top: 20px;
`;
const ButtonLink = styled.a`
    text-transform: uppercase;
    transition: 0.3s;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    position: relative;
    z-index: 2;

    ${({ $variant }) => $variant === "primary" && PrimaryVariant};
    ${({ $variant }) => $variant === "secondary" && SecondaryVariant};
`;
const Button$1 = ButtonLink.withComponent("button");
const PrimaryVariant = css`
    display: inline-flex;
    align-items: center;
    font-size: 25px;
    line-height: 30px;
    padding: 10px;
    transition: color 0.5s;
    transition-delay: 0.2s;

    ${MediaQuery.max("lg")} {
        font-size: 14px;
        line-height: 18px;
        margin-top: 20px;
    }

    &:before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 0%;
        background: ${Theme.primary};
        z-index: -1;
        transition: width 0.5s;
    }

    &:after {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 1px;
        background: ${Theme.primary};
        transition: width 0.5s;
    }

    &:hover {
        color: ${Theme.secondary};

        &:before {
            width: 100%;
        }

        &:after {
            width: 0%;
        }

        img {
            margin-right: 30px;
            opacity: 1;
        }
    }

    img {
        transition-delay: 0.2s;
        filter: invert(1);
        opacity: 0;
        margin-right: -20px;
        transition: all 0.5s;
    }
`;
const SecondaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.tertiary};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: ${Theme.tertiary};
    color: ${Theme.primary};

    &:hover {
        background: transparent;
        color: ${Theme.secondary};
    }
`;

const Button = ({
  link,
  target,
  children,
  align,
  showIcon = false,
  variant = "primary",
  asButton,
  type,
  ...rest
}) => {
  const ButtonComponent = asButton ? Button$1 : ButtonLink;
  return /* @__PURE__ */ jsx(ButtonWrapper, { $align: align, children: /* @__PURE__ */ jsxs(
    ButtonComponent,
    {
      href: link,
      target,
      ...rest,
      $variant: variant,
      children: [
        showIcon && /* @__PURE__ */ jsx(Icon, { iconData: "arrowRight", alt: "arrow icon" }),
        children
      ]
    }
  ) });
};

export { $$Layout as $, Button as B, Colors as C, FadeIn as F, HeroSlider as H, InfiniteImg1 as I, Logo as L, MediaQuery as M, PreviewPng as P, Theme as T, InfiniteImg2 as a, Fonts as b, Container as c, Icon as d, Logo$1 as e, HeroImg as f, HeroSlider3Preview as g, HeroSlider2Preview as h, HeroSlider1Preview as i };
