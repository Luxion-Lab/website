import { jsx, jsxs } from 'react/jsx-runtime';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery, C as Colors, c as Container, F as FadeIn, B as Button } from './index_B3DN2MbO.mjs';

const ContactFormContainer = styled.section`
    background: ${Theme.primary};
    padding: 60px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 0;
    z-index: 1;
    position: relative;
`;
styled.h2`
    font-size: 48px;
    line-height: 52px;
    font-weight: 900;
    text-align: center;
    margin-bottom: 20px;
    color: ${Theme.secondary};

    ${MediaQuery.max("lg")} {
        font-size: 36px;
        line-height: 40px;
    }

    ${MediaQuery.max("md")} {
        font-size: 28px;
        line-height: 32px;
    }
`;
styled.p`
    font-size: 18px;
    line-height: 24px;
    text-align: center;
    margin-bottom: 60px;
    color: ${Theme.secondary};
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;

    ${MediaQuery.max("lg")} {
        font-size: 16px;
        line-height: 22px;
        margin-bottom: 40px;
    }
`;
const ContactFormWrapper = styled.div`
    margin: 0 auto;
    background: ${Colors.white};
`;
const FormRow = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 5px;

    ${MediaQuery.max("md")} {
        grid-template-columns: 1fr;
        gap: 20px;
        margin-bottom: 5px;
    }
`;
const FormGroup = styled.div`
    display: flex;
    flex-direction: column;
    margin-bottom: 5px;

    ${MediaQuery.max("md")} {
        margin-bottom: 5px;
    }
`;
const FormLabel = styled.label`
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 8px;
    color: ${Theme.tertiary};
`;
const FormInput = styled.input`
    padding: 15px 20px;
    border: 2px solid ${({ $hasError }) => $hasError ? "#ff4444" : "#f4f4f4"};
    border-radius: 8px;
    background: ${Colors.white};
    font-size: 16px;
    transition: all 0.3s ease;

    &:focus {
        outline: none;
        border-color: ${Theme.tertiary};
        box-shadow: 0 0 0 3px rgba(0, 255, 255, 0.1);
    }

    &::placeholder {
        color: ${Colors.darkLighter};
    }

    ${MediaQuery.max("md")} {
        padding: 12px 16px;
        font-size: 14px;
    }
`;
const FormTextarea = styled.textarea`
    padding: 15px 20px;
    border: 2px solid ${({ $hasError }) => $hasError ? "#ff4444" : "#f4f4f4"};
    border-radius: 8px;
    background: ${Colors.white};
    font-size: 16px;
    font-family: inherit;
    resize: vertical;
    min-height: 120px;
    transition: all 0.3s ease;

    &:focus {
        outline: none;
        border-color: ${Theme.tertiary};
        box-shadow: 0 0 0 3px rgba(0, 255, 255, 0.1);
    }

    &::placeholder {
        color: ${Colors.darkLighter};
    }

    ${MediaQuery.max("md")} {
        padding: 12px 16px;
        font-size: 14px;
        min-height: 100px;
    }
`;
const ErrorMessage = styled.span`
    color: #ff4444;
    font-size: 14px;
    margin-top: 5px;
    display: block;
`;
const SuccessMessage = styled.div`
    background: #4CAF50;
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 500;
`;
const FormButtonWrapper = styled.div`
    display: flex;
    justify-content: flex-end;
    margin-top: 10px;
    padding-bottom: 30px;

    ${MediaQuery.max("md")} {
        margin-top: 10px;
        padding-bottom: 20px;
    }

    /* Ensure button inherits Hero button styling */
    > div {
        margin-top: 0;
    }
`;

const contactSchema = z.object({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  email: z.string().email("Por favor ingresa un email válido"),
  phone: z.string().min(10, "El teléfono debe tener al menos 10 dígitos"),
  company: z.string().optional(),
  message: z.string().min(10, "El mensaje debe tener al menos 10 caracteres")
});
const ContactForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState("idle");
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm({
    resolver: zodResolver(contactSchema)
  });
  const onSubmit = async (data) => {
    setIsSubmitting(true);
    setSubmitStatus("idle");
    const apiBody = {
      subject: `Nuevo mensaje de contacto de ${data.name} (${data.email})`,
      body: `Nombre: ${data.name}
Email: ${data.email}
Teléfono: ${data.phone}
Empresa: ${data.company || "-"}

Mensaje:
${data.message}`
    };
    try {
      const response = await fetch("https://luxion.ddns.net/api/send_email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(apiBody)
      });
      if (response.ok) {
        setSubmitStatus("success");
        reset();
      } else {
        setSubmitStatus("error");
      }
    } catch (error) {
      console.error("Error al enviar el formulario:", error);
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(ContactFormContainer, { children: /* @__PURE__ */ jsx(FadeIn, { delay: 0.2, children: /* @__PURE__ */ jsx(ContactFormWrapper, { children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit(onSubmit), children: [
    /* @__PURE__ */ jsxs(FormRow, { children: [
      /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(FormLabel, { children: "Nombre *" }),
        /* @__PURE__ */ jsx(
          FormInput,
          {
            ...register("name"),
            placeholder: "Tu nombre completo",
            $hasError: !!errors.name
          }
        ),
        errors.name && /* @__PURE__ */ jsx(ErrorMessage, { children: errors.name.message })
      ] }),
      /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(FormLabel, { children: "Email *" }),
        /* @__PURE__ */ jsx(
          FormInput,
          {
            ...register("email"),
            type: "email",
            placeholder: "tu@email.com",
            $hasError: !!errors.email
          }
        ),
        errors.email && /* @__PURE__ */ jsx(ErrorMessage, { children: errors.email.message })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(FormRow, { children: [
      /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(FormLabel, { children: "Teléfono *" }),
        /* @__PURE__ */ jsx(
          FormInput,
          {
            ...register("phone"),
            type: "tel",
            placeholder: "+1 000 000 0000",
            $hasError: !!errors.phone
          }
        ),
        errors.phone && /* @__PURE__ */ jsx(ErrorMessage, { children: errors.phone.message })
      ] }),
      /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(FormLabel, { children: "Empresa" }),
        /* @__PURE__ */ jsx(
          FormInput,
          {
            ...register("company"),
            placeholder: "Nombre de tu empresa"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs(FormGroup, { children: [
      /* @__PURE__ */ jsx(FormLabel, { children: "Mensaje *" }),
      /* @__PURE__ */ jsx(
        FormTextarea,
        {
          ...register("message"),
          placeholder: "Cuéntanos sobre tu proyecto y cómo podemos ayudarte...",
          rows: 4,
          $hasError: !!errors.message
        }
      ),
      errors.message && /* @__PURE__ */ jsx(ErrorMessage, { children: errors.message.message })
    ] }),
    submitStatus === "success" && /* @__PURE__ */ jsx(SuccessMessage, { children: "¡Gracias por contactarnos! Te responderemos pronto." }),
    submitStatus === "error" && /* @__PURE__ */ jsx(ErrorMessage, { children: "Hubo un error al enviar el mensaje. Por favor intenta de nuevo." }),
    /* @__PURE__ */ jsx(FormButtonWrapper, { children: /* @__PURE__ */ jsx(
      Button,
      {
        asButton: true,
        type: "submit",
        variant: "primary",
        showIcon: true,
        children: isSubmitting ? "Enviando..." : "Enviar mensaje"
      }
    ) })
  ] }) }) }) }) });
};

export { ContactForm as C };
