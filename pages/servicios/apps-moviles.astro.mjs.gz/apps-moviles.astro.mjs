import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { C as Colors, M as MediaQuery, b as Fonts, T as Theme, $ as $$Layout, H as HeroSlider, c as Container, I as InfiniteImg1 } from '../../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../../chunks/index_s5dUdJQS.mjs';
import { S as ServiceCards } from '../../chunks/index_CMV_vsGS.mjs';
import { F as Footer } from '../../chunks/index_BhCDT1zG.mjs';
import { P as ProcessStepper } from '../../chunks/index_CGmvxYTc.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import styled from '@emotion/styled';
import { keyframes } from '@emotion/react';
import { C as ContactForm } from '../../chunks/index_DMYogpyB.mjs';
import 'react';
/* empty css                                           */
export { renderers } from '../../renderers.mjs';

const slideAnimation = keyframes`
    0% {
        transform: translateX(0);
    }
    100% {
        transform: translateX(-50%);
    }
`;
const TechSliderContainer = styled.section`
    padding: 80px 0;
    background: ${Colors.white};
    overflow: hidden;

    ${MediaQuery.max("md")} {
        padding: 60px 0;
    }
`;
const TechSliderContent = styled.div`
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;

    ${MediaQuery.max("md")} {
        padding: 0 16px;
    }
`;
const TechSliderHeader = styled.div`
    text-align: center;
    margin-bottom: 60px;

    ${MediaQuery.max("md")} {
        margin-bottom: 40px;
    }
`;
const TechSliderSubtitle = styled.p`
    font-family: ${Fonts.primary};
    font-size: 14px;
    font-weight: 500;
    color: ${Theme.secondary};
    text-transform: uppercase;
    letter-spacing: 2px;
    margin: 0 0 16px 0;
    opacity: 0.8;

    ${MediaQuery.max("md")} {
        font-size: 12px;
        margin-bottom: 12px;
    }
`;
const TechSliderTitle = styled.h2`
    font-family: ${Fonts.primary};
    font-size: 42px;
    font-weight: 700;
    color: ${Theme.secondary};
    margin: 0 0 16px 0;
    line-height: 1.2;

    ${MediaQuery.max("md")} {
        font-size: 32px;
    }

    ${MediaQuery.max("sm")} {
        font-size: 28px;
    }
`;
const TechSliderDescription = styled.p`
    font-family: ${Fonts.primary};
    font-size: 18px;
    font-weight: 400;
    color: ${Theme.secondary};
    margin: 0 auto;
    line-height: 1.6;
    text-align: center;
    opacity: 0.8;

    ${MediaQuery.max("md")} {
        font-size: 16px;
    }

    ${MediaQuery.max("sm")} {
        font-size: 14px;
    }
`;
const TechSliderWrapper = styled.div`
    width: 100%;
    overflow: hidden;
    position: relative;
    
    &::before,
    &::after {
        content: '';
        position: absolute;
        top: 0;
        width: 100px;
        height: 100%;
        z-index: 2;
        pointer-events: none;
    }
    
    &::before {
        left: 0;
        background: linear-gradient(to right, ${Colors.white}, transparent);
    }
    
    &::after {
        right: 0;
        background: linear-gradient(to left, ${Colors.white}, transparent);
    }

    ${MediaQuery.max("md")} {
        &::before,
        &::after {
            width: 50px;
        }
    }
`;
const TechSliderTrack = styled.div`
    display: flex;
    animation: ${slideAnimation} 30s linear infinite;
    width: fit-content;
    padding: 20px 0;

    &:hover {
        animation-play-state: paused;
    }
`;
const TechSliderItem = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-width: 140px;
    height: 120px;
    margin: 0 20px;
    padding: 20px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    cursor: pointer;

    &:hover {
        transform: translateY(-8px);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
    }

    ${MediaQuery.max("md")} {
        min-width: 120px;
        height: 100px;
        margin: 0 15px;
        padding: 16px;
    }

    ${MediaQuery.max("sm")} {
        min-width: 100px;
        height: 90px;
        margin: 0 10px;
        padding: 12px;
    }
`;
const TechSliderLogo = styled.img`
    width: 40px;
    height: 40px;
    object-fit: contain;
    margin-bottom: 8px;

    ${MediaQuery.max("md")} {
        width: 36px;
        height: 36px;
        margin-bottom: 6px;
    }

    ${MediaQuery.max("sm")} {
        width: 32px;
        height: 32px;
        margin-bottom: 4px;
    }
`;
const TechSliderName = styled.span`
    font-family: ${Fonts.primary};
    font-size: 12px;
    font-weight: 600;
    color: ${Theme.secondary};
    text-align: center;
    line-height: 1.2;

    ${MediaQuery.max("md")} {
        font-size: 11px;
    }

    ${MediaQuery.max("sm")} {
        font-size: 10px;
    }
`;
const MobileTechSlider = ({
  title = "Tecnologías que usamos",
  subtitle = "STACK TECNOLÓGICO",
  description = "Usamos herramientas confiables, seguras y de última generación para crear apps móviles robustas y escalables."
}) => {
  const mobileTechnologies = [
    { name: "React Native", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" },
    { name: "Flutter", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg" },
    { name: "Swift", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/swift/swift-original.svg" },
    { name: "Kotlin", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kotlin/kotlin-original.svg" },
    { name: "Java", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" },
    { name: "Dart", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dart/dart-original.svg" },
    { name: "Ionic", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/ionic/ionic-original.svg" },
    { name: "Xamarin", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/xamarin/xamarin-original.svg" },
    { name: "Firebase", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firebase/firebase-plain.svg" },
    { name: "Node.js", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" },
    { name: "MongoDB", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" },
    { name: "AWS", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/amazonwebservices/amazonwebservices-original-wordmark.svg" }
  ];
  return /* @__PURE__ */ jsx(TechSliderContainer, { children: /* @__PURE__ */ jsxs(TechSliderContent, { children: [
    /* @__PURE__ */ jsxs(TechSliderHeader, { children: [
      /* @__PURE__ */ jsx(TechSliderSubtitle, { children: subtitle }),
      /* @__PURE__ */ jsx(TechSliderTitle, { children: title }),
      /* @__PURE__ */ jsx(TechSliderDescription, { children: description })
    ] }),
    /* @__PURE__ */ jsx(TechSliderWrapper, { children: /* @__PURE__ */ jsxs(TechSliderTrack, { children: [
      mobileTechnologies.map((tech, index) => /* @__PURE__ */ jsxs(TechSliderItem, { children: [
        /* @__PURE__ */ jsx(TechSliderLogo, { src: tech.logo, alt: tech.name }),
        /* @__PURE__ */ jsx(TechSliderName, { children: tech.name })
      ] }, `first-${index}`)),
      mobileTechnologies.map((tech, index) => /* @__PURE__ */ jsxs(TechSliderItem, { children: [
        /* @__PURE__ */ jsx(TechSliderLogo, { src: tech.logo, alt: tech.name }),
        /* @__PURE__ */ jsx(TechSliderName, { children: tech.name })
      ] }, `second-${index}`))
    ] }) })
  ] }) });
};

const $$AppsMoviles = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Desarrollo de Apps M\xF3viles | Aplicaciones iOS y Android a medida | Luxion", "description": "Dise\xF1amos y desarrollamos aplicaciones m\xF3viles personalizadas para Android y iOS. Experiencias modernas, r\xE1pidas y seguras que conectan tu negocio con tus usuarios.", "data-astro-cid-mrg3rzen": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content" data-astro-cid-mrg3rzen> <!-- Hero Section --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Creamos apps m\xF3viles que conectan ideas con resultados",
      paragraph: "En Luxion desarrollamos aplicaciones m\xF3viles a medida, modernas, seguras y escalables. Lleva tu negocio a la palma de la mano de tus clientes."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-mrg3rzen": true })} ${renderComponent($$result2, "Container", Container, { "data-astro-cid-mrg3rzen": true }, { "default": ($$result3) => renderTemplate`  ${renderComponent($$result3, "ServiceCards", ServiceCards, { "description": "APPS M\xD3VILES", "title": "Aplicaciones m\xF3viles dise\xF1adas para crecer contigo", "client:visible": true, "cards": [
    {
      title: "\u{1F4F2} App de gesti\xF3n interna para equipos de trabajo",
      description: "Herramientas m\xF3viles que optimizan la comunicaci\xF3n y productividad de tu equipo desde cualquier lugar."
    },
    {
      title: "\u26A1 Aplicaci\xF3n de reservas o pedidos con notificaciones push",
      description: "Sistemas de reservas y pedidos en tiempo real con notificaciones inteligentes para tus clientes."
    },
    {
      title: "\u{1F9E0} App educativa con integraci\xF3n a plataformas web",
      description: "Aplicaciones de aprendizaje que se sincronizan perfectamente con tus sistemas web existentes."
    },
    {
      title: "\u{1F512} Aplicaci\xF3n de seguimiento y reportes para empresas",
      description: "Dashboards m\xF3viles seguros para monitorear m\xE9tricas y generar reportes desde tu dispositivo."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards", "data-astro-cid-mrg3rzen": true })}  ${renderComponent($$result3, "MobileTechSlider", MobileTechSlider, { "client:visible": true, "title": "\u{1F4F1} Tecnolog\xEDa moderna para apps r\xE1pidas y seguras", "subtitle": "TECNOLOG\xCDAS M\xD3VILES", "description": "Utilizamos las mejores tecnolog\xEDas y frameworks para crear aplicaciones m\xF3viles nativas y multiplataforma que ofrecen rendimiento excepcional.", "client:component-hydration": "visible", "client:component-path": "@components/MobileTechSlider", "client:component-export": "MobileTechSlider", "data-astro-cid-mrg3rzen": true })}  ${renderComponent($$result3, "ProcessStepper", ProcessStepper, { "client:visible": true, "title": "\u{1F4F1} De la idea al lanzamiento, paso a paso", "subtitle": "PROCESO DE DESARROLLO", "description": "Transformamos tu idea en una app exitosa siguiendo un proceso probado que garantiza calidad y resultados.", "steps": [
    {
      number: "1",
      title: "An\xE1lisis y Planificaci\xF3n",
      description: "Definimos objetivos, audiencia target y funcionalidades clave. Creamos wireframes y especificaciones t\xE9cnicas detalladas."
    },
    {
      number: "2",
      title: "Dise\xF1o UX/UI",
      description: "Dise\xF1amos interfaces intuitivas y atractivas que ofrecen la mejor experiencia de usuario en dispositivos m\xF3viles."
    },
    {
      number: "3",
      title: "Desarrollo y Testing",
      description: "Desarrollamos tu app con c\xF3digo limpio y realizamos pruebas exhaustivas en diferentes dispositivos y sistemas operativos."
    },
    {
      number: "4",
      title: "Lanzamiento y Soporte",
      description: "Publicamos tu app en las tiendas oficiales y te brindamos soporte continuo para actualizaciones y mejoras."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@components/ProcessStepper", "client:component-export": "ProcessStepper", "data-astro-cid-mrg3rzen": true })}  <section class="benefits-section" data-astro-cid-mrg3rzen> <div class="container" data-astro-cid-mrg3rzen> <div class="section-header" data-astro-cid-mrg3rzen> <h2 data-astro-cid-mrg3rzen>Por qué elegirnos para tu app móvil</h2> <p data-astro-cid-mrg3rzen>
Con Luxion, obtienes más que una aplicación: obtienes un producto sólido, fácil de mantener y diseñado para escalar.
</p> </div> <div class="benefits-grid" data-astro-cid-mrg3rzen> <div class="benefit-item" data-astro-cid-mrg3rzen> <span class="check-icon" data-astro-cid-mrg3rzen>✅</span> <span data-astro-cid-mrg3rzen>Desarrollo multiplataforma (Android e iOS)</span> </div> <div class="benefit-item" data-astro-cid-mrg3rzen> <span class="check-icon" data-astro-cid-mrg3rzen>✅</span> <span data-astro-cid-mrg3rzen>Experiencias rápidas y fluidas</span> </div> <div class="benefit-item" data-astro-cid-mrg3rzen> <span class="check-icon" data-astro-cid-mrg3rzen>✅</span> <span data-astro-cid-mrg3rzen>Integración total con tus sistemas existentes</span> </div> <div class="benefit-item" data-astro-cid-mrg3rzen> <span class="check-icon" data-astro-cid-mrg3rzen>✅</span> <span data-astro-cid-mrg3rzen>Escalabilidad y soporte continuo</span> </div> </div> </div> </section>  ${renderComponent($$result3, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 600,
      height: 400,
      alt: "Desarrollo de aplicaciones m\xF3viles"
    },
    title: "\u{1F4F2} \xBFListo para lanzar tu pr\xF3xima app?",
    paragraph: "Conecta con tus clientes de forma directa y moderna. Nuestro equipo convierte tus ideas en aplicaciones m\xF3viles potentes y f\xE1ciles de usar."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-mrg3rzen": true })} ${renderComponent($$result3, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm", "data-astro-cid-mrg3rzen": true })} ` })} </main> ${renderComponent($$result2, "Footer", Footer, { "data-astro-cid-mrg3rzen": true })} ` })} `;
}, "/home/runner/work/website/website/src/pages/servicios/apps-moviles.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/servicios/apps-moviles.astro";
const $$url = "/servicios/apps-moviles";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$AppsMoviles,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
