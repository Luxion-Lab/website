import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout, H as HeroSlider, c as Container, I as InfiniteImg1 } from '../../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../../chunks/index_s5dUdJQS.mjs';
import { S as ServiceCards } from '../../chunks/index_CMV_vsGS.mjs';
import { F as Footer } from '../../chunks/index_BhCDT1zG.mjs';
import { C as ContactForm } from '../../chunks/index_DMYogpyB.mjs';
import 'react/jsx-runtime';
import 'react';
/* empty css                                            */
export { renderers } from '../../renderers.mjs';

const $$Integraciones = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Integraciones entre Sistemas | Conecta tus plataformas y optimiza tu flujo digital | Luxion", "description": "Integra tus herramientas y plataformas en un solo flujo de trabajo. En Luxion conectamos tus sistemas para que compartan datos y trabajen como uno solo.", "data-astro-cid-pqyv7isp": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content" data-astro-cid-pqyv7isp> <!-- Hero Section --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Conectamos tus herramientas, potenciamos tu productividad",
      paragraph: "En Luxion, unimos tus aplicaciones, sistemas y bases de datos para que trabajen en sincron\xEDa. Logra una operaci\xF3n fluida, sin duplicar esfuerzos."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-pqyv7isp": true })} ${renderComponent($$result2, "Container", Container, { "data-astro-cid-pqyv7isp": true }, { "default": ($$result3) => renderTemplate`  ${renderComponent($$result3, "ServiceCards", ServiceCards, { "description": "INTEGRACIONES", "title": "Todas tus herramientas, sincronizadas y funcionando como un ecosistema", "client:visible": true, "cards": [
    {
      title: "\u{1F9E9} Conecta tu CRM con tu web y tu sistema de facturaci\xF3n",
      description: "Sincronizaci\xF3n autom\xE1tica de leads, clientes y facturaci\xF3n entre todas tus plataformas principales."
    },
    {
      title: "\u2699\uFE0F Sincroniza tus hojas de c\xE1lculo con tu base de datos",
      description: "Actualizaci\xF3n bidireccional en tiempo real entre Excel, Google Sheets y tus sistemas de gesti\xF3n."
    },
    {
      title: "\u{1F4E1} Integra tu tienda online con tu sistema de inventario",
      description: "Control autom\xE1tico de stock, pedidos y log\xEDstica entre e-commerce y gesti\xF3n de inventario."
    },
    {
      title: "\u{1F680} Conecta tus formularios web con herramientas de marketing",
      description: "Flujo directo de leads desde formularios hacia CRM, email marketing y sistemas de seguimiento."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards", "data-astro-cid-pqyv7isp": true })}  <section class="benefits-section" data-astro-cid-pqyv7isp> <div class="container" data-astro-cid-pqyv7isp> <div class="section-header" data-astro-cid-pqyv7isp> <h2 data-astro-cid-pqyv7isp>El poder de tener todos tus sistemas conectados</h2> <p data-astro-cid-pqyv7isp>
Con nuestras integraciones, eliminas tareas duplicadas, mejoras la precisión de tus datos y optimizas la comunicación entre áreas.
</p> </div> <div class="benefits-grid" data-astro-cid-pqyv7isp> <div class="benefit-item" data-astro-cid-pqyv7isp> <span class="check-icon" data-astro-cid-pqyv7isp>✅</span> <span data-astro-cid-pqyv7isp>Un solo flujo de datos entre todas tus herramientas</span> </div> <div class="benefit-item" data-astro-cid-pqyv7isp> <span class="check-icon" data-astro-cid-pqyv7isp>✅</span> <span data-astro-cid-pqyv7isp>Reducción de errores manuales</span> </div> <div class="benefit-item" data-astro-cid-pqyv7isp> <span class="check-icon" data-astro-cid-pqyv7isp>✅</span> <span data-astro-cid-pqyv7isp>Ahorro de tiempo y esfuerzo operativo</span> </div> <div class="benefit-item" data-astro-cid-pqyv7isp> <span class="check-icon" data-astro-cid-pqyv7isp>✅</span> <span data-astro-cid-pqyv7isp>Mayor visibilidad y control sobre tu negocio</span> </div> <div class="benefit-item" data-astro-cid-pqyv7isp> <span class="check-icon" data-astro-cid-pqyv7isp>✅</span> <span data-astro-cid-pqyv7isp>Flexibilidad para crecer e incorporar nuevas plataformas</span> </div> </div> </div> </section>  <section class="technologies-section" data-astro-cid-pqyv7isp> <div class="container" data-astro-cid-pqyv7isp> <div class="section-header" data-astro-cid-pqyv7isp> <h2 data-astro-cid-pqyv7isp>Conectamos lo que usas con lo que necesitas</h2> <p data-astro-cid-pqyv7isp>
Trabajamos con APIs y servicios de integración líderes para garantizar compatibilidad, seguridad y estabilidad.
</p> </div> <div class="tech-categories" data-astro-cid-pqyv7isp> <div class="tech-category" data-astro-cid-pqyv7isp> <h3 data-astro-cid-pqyv7isp>Plataformas de Integración</h3> <div class="tech-items" data-astro-cid-pqyv7isp> <span class="tech-item" data-astro-cid-pqyv7isp>Make</span> <span class="tech-item" data-astro-cid-pqyv7isp>Zapier</span> <span class="tech-item" data-astro-cid-pqyv7isp>n8n</span> <span class="tech-item" data-astro-cid-pqyv7isp>Pabbly Connect</span> </div> </div> <div class="tech-category" data-astro-cid-pqyv7isp> <h3 data-astro-cid-pqyv7isp>APIs y Protocolos</h3> <div class="tech-items" data-astro-cid-pqyv7isp> <span class="tech-item" data-astro-cid-pqyv7isp>REST API</span> <span class="tech-item" data-astro-cid-pqyv7isp>GraphQL</span> <span class="tech-item" data-astro-cid-pqyv7isp>Webhooks</span> <span class="tech-item" data-astro-cid-pqyv7isp>Custom APIs</span> </div> </div> <div class="tech-category" data-astro-cid-pqyv7isp> <h3 data-astro-cid-pqyv7isp>Sistemas Compatibles</h3> <div class="tech-items" data-astro-cid-pqyv7isp> <span class="tech-item" data-astro-cid-pqyv7isp>WordPress</span> <span class="tech-item" data-astro-cid-pqyv7isp>Shopify</span> <span class="tech-item" data-astro-cid-pqyv7isp>Google Sheets</span> <span class="tech-item" data-astro-cid-pqyv7isp>HubSpot</span> <span class="tech-item" data-astro-cid-pqyv7isp>Notion</span> <span class="tech-item" data-astro-cid-pqyv7isp>Slack</span> </div> </div> </div> </div> </section>  <section class="success-cases" data-astro-cid-pqyv7isp> <div class="container" data-astro-cid-pqyv7isp> <div class="section-header" data-astro-cid-pqyv7isp> <h2 data-astro-cid-pqyv7isp>Integraciones que generan impacto real</h2> <p data-astro-cid-pqyv7isp>
Hemos ayudado a empresas a centralizar sus datos y mejorar su productividad conectando herramientas que antes trabajaban por separado.
</p> </div> <div class="cases-grid" data-astro-cid-pqyv7isp> <div class="case-card" data-astro-cid-pqyv7isp> <div class="case-icon" data-astro-cid-pqyv7isp>📊</div> <h3 data-astro-cid-pqyv7isp>Integración CRM + Marketing</h3> <p data-astro-cid-pqyv7isp>Integración de formularios web con CRM y automatización de leads para seguimiento personalizado</p> <div class="case-metric" data-astro-cid-pqyv7isp>+85% conversión leads</div> </div> <div class="case-card" data-astro-cid-pqyv7isp> <div class="case-icon" data-astro-cid-pqyv7isp>💼</div> <h3 data-astro-cid-pqyv7isp>E-commerce + Contabilidad</h3> <p data-astro-cid-pqyv7isp>Sincronización de inventario entre tienda online y sistema contable con control automático de stock</p> <div class="case-metric" data-astro-cid-pqyv7isp>-90% errores inventario</div> </div> <div class="case-card" data-astro-cid-pqyv7isp> <div class="case-icon" data-astro-cid-pqyv7isp>📈</div> <h3 data-astro-cid-pqyv7isp>Marketing Multicanal</h3> <p data-astro-cid-pqyv7isp>Conexión de herramientas de marketing para medir conversiones en tiempo real y optimizar campañas</p> <div class="case-metric" data-astro-cid-pqyv7isp>+150% ROI marketing</div> </div> </div> </div> </section>  ${renderComponent($$result3, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 600,
      height: 400,
      alt: "Integraci\xF3n de sistemas empresariales"
    },
    title: "\u{1F517} \xBFListo para conectar tus sistemas?",
    paragraph: "Da el siguiente paso hacia una operaci\xF3n m\xE1s inteligente y sin fricciones. Nuestro equipo te ayuda a dise\xF1ar integraciones seguras, escalables y a medida de tu negocio."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-pqyv7isp": true })} ${renderComponent($$result3, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm", "data-astro-cid-pqyv7isp": true })} ` })} </main> ${renderComponent($$result2, "Footer", Footer, { "data-astro-cid-pqyv7isp": true })} ` })} `;
}, "/home/runner/work/website/website/src/pages/servicios/integraciones.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/servicios/integraciones.astro";
const $$url = "/servicios/integraciones";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Integraciones,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
