import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { C as Colors, M as MediaQuery, b as Fonts, T as Theme, $ as $$Layout, H as HeroSlider, c as Container, a as InfiniteImg2 } from '../../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../../chunks/index_s5dUdJQS.mjs';
import { S as ServiceCards } from '../../chunks/index_CMV_vsGS.mjs';
import { F as Footer } from '../../chunks/index_BhCDT1zG.mjs';
import { P as ProcessStepper } from '../../chunks/index_CGmvxYTc.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import styled from '@emotion/styled';
import { keyframes } from '@emotion/react';
import { C as ContactForm } from '../../chunks/index_DMYogpyB.mjs';
import 'react';
export { renderers } from '../../renderers.mjs';

const slideAnimation = keyframes`
    0% {
        transform: translateX(0);
    }
    100% {
        transform: translateX(-50%);
    }
`;
const TechSliderContainer = styled.section`
    padding: 80px 0;
    background: ${Colors.white};
    overflow: hidden;

    ${MediaQuery.max("md")} {
        padding: 60px 0;
    }
`;
const TechSliderContent = styled.div`
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;

    ${MediaQuery.max("md")} {
        padding: 0 16px;
    }
`;
const TechSliderHeader = styled.div`
    text-align: center;
    margin-bottom: 60px;

    ${MediaQuery.max("md")} {
        margin-bottom: 40px;
    }
`;
const TechSliderSubtitle = styled.p`
    font-family: ${Fonts.primary};
    font-size: 14px;
    font-weight: 500;
    color: ${Theme.secondary};
    text-transform: uppercase;
    letter-spacing: 2px;
    margin: 0 0 16px 0;
    opacity: 0.8;

    ${MediaQuery.max("md")} {
        font-size: 12px;
        margin-bottom: 12px;
    }
`;
const TechSliderTitle = styled.h2`
    font-family: ${Fonts.primary};
    font-size: 42px;
    font-weight: 700;
    color: ${Theme.secondary};
    margin: 0 0 16px 0;
    line-height: 1.2;

    ${MediaQuery.max("md")} {
        font-size: 32px;
    }

    ${MediaQuery.max("sm")} {
        font-size: 28px;
    }
`;
const TechSliderDescription = styled.p`
    font-family: ${Fonts.primary};
    font-size: 18px;
    font-weight: 400;
    color: ${Theme.secondary};
    margin: 0 auto;
    line-height: 1.6;
    text-align: center;
    opacity: 0.8;

    ${MediaQuery.max("md")} {
        font-size: 16px;
    }

    ${MediaQuery.max("sm")} {
        font-size: 14px;
    }
`;
const TechSliderWrapper = styled.div`
    width: 100%;
    overflow: hidden;
    position: relative;
    
    &::before,
    &::after {
        content: '';
        position: absolute;
        top: 0;
        width: 100px;
        height: 100%;
        z-index: 2;
        pointer-events: none;
    }
    
    &::before {
        left: 0;
        background: linear-gradient(to right, ${Colors.white}, transparent);
    }
    
    &::after {
        right: 0;
        background: linear-gradient(to left, ${Colors.white}, transparent);
    }

    ${MediaQuery.max("md")} {
        &::before,
        &::after {
            width: 50px;
        }
    }
`;
const TechSliderTrack = styled.div`
    display: flex;
    animation: ${slideAnimation} 30s linear infinite;
    width: fit-content;
    padding: 20px 0;

    &:hover {
        animation-play-state: paused;
    }
`;
const TechSliderItem = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-width: 140px;
    height: 120px;
    margin: 0 20px;
    padding: 20px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    cursor: pointer;

    &:hover {
        transform: translateY(-8px);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
    }

    ${MediaQuery.max("md")} {
        min-width: 120px;
        height: 100px;
        margin: 0 15px;
        padding: 16px;
    }

    ${MediaQuery.max("sm")} {
        min-width: 100px;
        height: 90px;
        margin: 0 10px;
        padding: 12px;
    }
`;
const TechSliderLogo = styled.img`
    width: 40px;
    height: 40px;
    object-fit: contain;
    margin-bottom: 8px;

    ${MediaQuery.max("md")} {
        width: 36px;
        height: 36px;
        margin-bottom: 6px;
    }

    ${MediaQuery.max("sm")} {
        width: 32px;
        height: 32px;
        margin-bottom: 4px;
    }
`;
const TechSliderName = styled.span`
    font-family: ${Fonts.primary};
    font-size: 12px;
    font-weight: 600;
    color: ${Theme.secondary};
    text-align: center;
    line-height: 1.2;

    ${MediaQuery.max("md")} {
        font-size: 11px;
    }

    ${MediaQuery.max("sm")} {
        font-size: 10px;
    }
`;
const ChatbotTechSlider = ({
  title = "Tecnologías de IA y automatización",
  subtitle = "TECNOLOGÍAS DE CHATBOTS",
  description = "Utilizamos las mejores herramientas de inteligencia artificial y procesamiento de lenguaje natural para crear chatbots inteligentes y efectivos."
}) => {
  const technologies = [
    { name: "OpenAI GPT", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/ChatGPT_logo.svg/1024px-ChatGPT_logo.svg.png", isComponent: false },
    { name: "Dialogflow", logo: "https://cloudaiworld.com/wp-content/uploads/2022/01/dialogflow-logo.png", isComponent: false },
    { name: "Botpress", logo: "https://avatars.githubusercontent.com/u/23510677?s=200&v=4", isComponent: false },
    { name: "IBM Watson", logo: "https://logodix.com/logo/44136.png", isComponent: false },
    { name: "Hugging Face", logo: "https://cdn.worldvectorlogo.com/logos/huggingface-2.svg", isComponent: false },
    { name: "LangChain", logo: "https://registry.npmmirror.com/@lobehub/icons-static-png/latest/files/dark/langgraph-color.png", isComponent: false },
    { name: "Microsoft Bot", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/azure/azure-original.svg", isComponent: false },
    { name: "Wit.ai", logo: "https://inten.to/img/api/wit_ai_detect_intent.png", isComponent: false },
    { name: "TensorFlow", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tensorflow/tensorflow-original.svg", isComponent: false },
    { name: "PyTorch", logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/pytorch/pytorch-original.svg", isComponent: false }
  ];
  return /* @__PURE__ */ jsx(TechSliderContainer, { children: /* @__PURE__ */ jsxs(TechSliderContent, { children: [
    /* @__PURE__ */ jsxs(TechSliderHeader, { children: [
      /* @__PURE__ */ jsx(TechSliderSubtitle, { children: subtitle }),
      /* @__PURE__ */ jsx(TechSliderTitle, { children: title }),
      /* @__PURE__ */ jsx(TechSliderDescription, { children: description })
    ] }),
    /* @__PURE__ */ jsx(TechSliderWrapper, { children: /* @__PURE__ */ jsxs(TechSliderTrack, { children: [
      technologies.map((tech, index) => /* @__PURE__ */ jsxs(TechSliderItem, { children: [
        tech.isComponent ? /* @__PURE__ */ jsx("div", { style: { marginBottom: "8px" }, children: tech.logo }) : /* @__PURE__ */ jsx(TechSliderLogo, { src: tech.logo, alt: tech.name }),
        /* @__PURE__ */ jsx(TechSliderName, { children: tech.name })
      ] }, `first-${index}`)),
      technologies.map((tech, index) => /* @__PURE__ */ jsxs(TechSliderItem, { children: [
        tech.isComponent ? /* @__PURE__ */ jsx("div", { style: { marginBottom: "8px" }, children: tech.logo }) : /* @__PURE__ */ jsx(TechSliderLogo, { src: tech.logo, alt: tech.name }),
        /* @__PURE__ */ jsx(TechSliderName, { children: tech.name })
      ] }, `second-${index}`))
    ] }) })
  ] }) });
};

const $$IaChatbots = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Chatbots con IA | Automatiza la atenci\xF3n y las ventas con Luxion", "description": "Dise\xF1amos chatbots inteligentes para automatizar la atenci\xF3n, aumentar tus ventas y ofrecer respuestas instant\xE1neas 24/7 en WhatsApp, web o redes sociales." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> <!-- Hero Principal --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Chatbots con Inteligencia Artificial que entienden, responden y convierten",
      paragraph: "En Luxion, desarrollamos chatbots impulsados por IA que automatizan la atenci\xF3n al cliente, mejoran la experiencia de los usuarios y aumentan las conversiones en tus canales digitales. Nuestros asistentes virtuales pueden integrarse en WhatsApp, Messenger, Instagram, tu sitio web o tu aplicaci\xF3n para responder de forma natural y personalizada."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Container", Container, {}, { "default": ($$result3) => renderTemplate`  ${renderComponent($$result3, "ServiceCards", ServiceCards, { "description": "AUTOMATIZACI\xD3N INTELIGENTE", "title": "\xBFPor qu\xE9 elegir un chatbot inteligente?", "client:visible": true, "cards": [
    {
      title: "\u{1F4A1} Disponibilidad 24/7",
      description: "Atenci\xF3n autom\xE1tica sin interrupciones, siempre disponible para tus clientes cuando m\xE1s lo necesitan."
    },
    {
      title: "\u2699\uFE0F Automatizaci\xF3n total",
      description: "Responde preguntas frecuentes y gestiona solicitudes comunes autom\xE1ticamente, liberando tiempo de tu equipo."
    },
    {
      title: "\u{1F680} M\xE1s ventas",
      description: "Gu\xEDa a los usuarios hacia la compra o reserva con conversaciones inteligentes y personalizadas."
    },
    {
      title: "\u{1F4CA} Datos \xFAtiles",
      description: "Recopila m\xE9tricas y opiniones de clientes para mejorar continuamente tu negocio."
    },
    {
      title: "\u{1F517} Integraci\xF3n sencilla",
      description: "Conecta con CRM, sistemas internos o tu web sin complicaciones t\xE9cnicas."
    },
    {
      title: "\u{1F6CD}\uFE0F Casos de uso vers\xE1tiles",
      description: "Desde e-commerce hasta servicios financieros, adaptamos el chatbot a tu industria espec\xEDfica."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })}  ${renderComponent($$result3, "ProcessStepper", ProcessStepper, { "client:visible": true, "title": "\u{1F916} Proceso de creaci\xF3n del chatbot", "subtitle": "METODOLOG\xCDA PROBADA", "description": "Seguimos un proceso estructurado para crear chatbots que realmente funcionen para tu negocio y generen resultados medibles.", "steps": [
    {
      number: "1",
      title: "An\xE1lisis de necesidades",
      description: "Definimos los flujos de conversaci\xF3n y objetivos espec\xEDficos de tu negocio para crear la estrategia perfecta."
    },
    {
      number: "2",
      title: "Entrenamiento del modelo IA",
      description: "Desarrollamos el modelo con lenguaje natural adaptado a tu industria, marca y tono de comunicaci\xF3n."
    },
    {
      number: "3",
      title: "Dise\xF1o conversacional UX/UI",
      description: "Creamos una experiencia amigable, humana y clara que tus usuarios disfrutar\xE1n usar."
    },
    {
      number: "4",
      title: "Integraci\xF3n t\xE9cnica",
      description: "Conectamos con APIs, bases de datos o plataformas existentes para un funcionamiento seamless."
    },
    {
      number: "5",
      title: "Pruebas y optimizaci\xF3n continua",
      description: "Monitoreamos el rendimiento y mejoramos constantemente las respuestas bas\xE1ndonos en datos reales."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@components/ProcessStepper", "client:component-export": "ProcessStepper" })}  ${renderComponent($$result3, "ChatbotTechSlider", ChatbotTechSlider, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ChatbotTechSlider", "client:component-export": "ChatbotTechSlider" })}  ${renderComponent($$result3, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg2.src,
      width: 600,
      height: 400,
      alt: "Chatbot inteligente automatizando atenci\xF3n al cliente"
    },
    title: "\u{1F4AC} Lleva tu negocio al siguiente nivel con un chatbot inteligente",
    paragraph: "Automatiza la atenci\xF3n, mejora tus resultados y brinda una experiencia \xFAnica a tus clientes. Nuestro equipo est\xE1 listo para crear el chatbot perfecto para tu negocio. Cont\xE1ctanos hoy y recibe una demo personalizada."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result3, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm" })} ` })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/home/runner/work/website/website/src/pages/servicios/ia-chatbots.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/servicios/ia-chatbots.astro";
const $$url = "/servicios/ia-chatbots";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$IaChatbots,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
