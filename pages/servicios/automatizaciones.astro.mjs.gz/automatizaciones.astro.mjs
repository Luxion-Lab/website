import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout, H as HeroSlider, c as Container, I as InfiniteImg1 } from '../../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../../chunks/index_s5dUdJQS.mjs';
import { S as ServiceCards } from '../../chunks/index_CMV_vsGS.mjs';
import { F as Footer } from '../../chunks/index_BhCDT1zG.mjs';
import { C as ContactForm } from '../../chunks/index_DMYogpyB.mjs';
import 'react/jsx-runtime';
import 'react';
/* empty css                                               */
export { renderers } from '../../renderers.mjs';

const $$Automatizaciones = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Automatizaciones Inteligentes | Optimiza tus procesos con IA y flujos digitales | Luxion", "description": "Ahorra tiempo y elimina tareas repetitivas con automatizaciones inteligentes. Integramos tus herramientas y optimizamos tus procesos con tecnolog\xEDa moderna.", "data-astro-cid-n2ppamca": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content" data-astro-cid-n2ppamca> <!-- Hero Section --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Automatiza tu negocio y gana tiempo para lo que importa",
      paragraph: "Creamos automatizaciones inteligentes que conectan tus sistemas, ejecutan tareas de forma aut\xF3noma y te ayudan a operar con m\xE1xima eficiencia."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-n2ppamca": true })} ${renderComponent($$result2, "Container", Container, { "data-astro-cid-n2ppamca": true }, { "default": ($$result3) => renderTemplate`  ${renderComponent($$result3, "ServiceCards", ServiceCards, { "description": "AUTOMATIZACIONES", "title": "Transformamos tus procesos en flujos inteligentes", "client:visible": true, "cards": [
    {
      title: "\u{1F4E7} Env\xEDo autom\xE1tico de correos",
      description: "Notificaciones desde tu CRM y seguimiento automatizado de leads con personalizaci\xF3n completa."
    },
    {
      title: "\u{1F504} Sincronizaci\xF3n de datos",
      description: "Integraci\xF3n entre sistemas ERP, web y contabilidad en tiempo real sin errores manuales."
    },
    {
      title: "\u{1F916} Bots inteligentes",
      description: "Clasificaci\xF3n autom\xE1tica de leads y respuestas de clientes con inteligencia artificial."
    },
    {
      title: "\u{1F4CA} Reportes autom\xE1ticos",
      description: "Generaci\xF3n de reportes y hojas de c\xE1lculo sin intervenci\xF3n manual, siempre actualizados."
    },
    {
      title: "\u{1F4B0} Flujos de ventas",
      description: "Automatizaci\xF3n completa de procesos de ventas y facturaci\xF3n desde lead hasta cobro."
    },
    {
      title: "\u26A1 Integraci\xF3n total",
      description: "Conexi\xF3n fluida entre todas tus herramientas de trabajo para m\xE1xima eficiencia."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards", "data-astro-cid-n2ppamca": true })}  <section class="benefits-section" data-astro-cid-n2ppamca> <div class="container" data-astro-cid-n2ppamca> <div class="section-header" data-astro-cid-n2ppamca> <h2 data-astro-cid-n2ppamca>Resultados medibles con cada automatización</h2> <p data-astro-cid-n2ppamca>
Nuestras automatizaciones te permiten enfocarte en el crecimiento, reduciendo errores y aumentando la productividad.
</p> </div> <div class="benefits-grid" data-astro-cid-n2ppamca> <div class="benefit-item" data-astro-cid-n2ppamca> <span class="check-icon" data-astro-cid-n2ppamca>✅</span> <span data-astro-cid-n2ppamca>Reducción de costos operativos</span> </div> <div class="benefit-item" data-astro-cid-n2ppamca> <span class="check-icon" data-astro-cid-n2ppamca>✅</span> <span data-astro-cid-n2ppamca>Eliminación de tareas repetitivas</span> </div> <div class="benefit-item" data-astro-cid-n2ppamca> <span class="check-icon" data-astro-cid-n2ppamca>✅</span> <span data-astro-cid-n2ppamca>Integración sin interrupciones entre sistemas</span> </div> <div class="benefit-item" data-astro-cid-n2ppamca> <span class="check-icon" data-astro-cid-n2ppamca>✅</span> <span data-astro-cid-n2ppamca>Mayor eficiencia y trazabilidad</span> </div> <div class="benefit-item" data-astro-cid-n2ppamca> <span class="check-icon" data-astro-cid-n2ppamca>✅</span> <span data-astro-cid-n2ppamca>Aumento del enfoque estratégico del equipo</span> </div> </div> </div> </section>  <section class="technologies-section" data-astro-cid-n2ppamca> <div class="container" data-astro-cid-n2ppamca> <div class="section-header" data-astro-cid-n2ppamca> <h2 data-astro-cid-n2ppamca>Automatización con tecnología de vanguardia</h2> <p data-astro-cid-n2ppamca>
Usamos herramientas líderes para conectar, integrar y automatizar procesos empresariales con precisión y seguridad.
</p> </div> <div class="tech-categories" data-astro-cid-n2ppamca> <div class="tech-category" data-astro-cid-n2ppamca> <h3 data-astro-cid-n2ppamca>Plataformas de Automatización</h3> <div class="tech-items" data-astro-cid-n2ppamca> <span class="tech-item" data-astro-cid-n2ppamca>Make</span> <span class="tech-item" data-astro-cid-n2ppamca>n8n</span> <span class="tech-item" data-astro-cid-n2ppamca>Zapier</span> <span class="tech-item" data-astro-cid-n2ppamca>Pabbly Connect</span> </div> </div> <div class="tech-category" data-astro-cid-n2ppamca> <h3 data-astro-cid-n2ppamca>APIs y Scripts</h3> <div class="tech-items" data-astro-cid-n2ppamca> <span class="tech-item" data-astro-cid-n2ppamca>Python</span> <span class="tech-item" data-astro-cid-n2ppamca>Node.js</span> <span class="tech-item" data-astro-cid-n2ppamca>Webhooks REST</span> </div> </div> <div class="tech-category" data-astro-cid-n2ppamca> <h3 data-astro-cid-n2ppamca>Integraciones</h3> <div class="tech-items" data-astro-cid-n2ppamca> <span class="tech-item" data-astro-cid-n2ppamca>Google Workspace</span> <span class="tech-item" data-astro-cid-n2ppamca>Notion</span> <span class="tech-item" data-astro-cid-n2ppamca>Slack</span> <span class="tech-item" data-astro-cid-n2ppamca>Airtable</span> <span class="tech-item" data-astro-cid-n2ppamca>WordPress</span> </div> </div> </div> </div> </section>  <section class="success-cases" data-astro-cid-n2ppamca> <div class="container" data-astro-cid-n2ppamca> <div class="section-header" data-astro-cid-n2ppamca> <h2 data-astro-cid-n2ppamca>Ejemplos reales de automatización con impacto</h2> <p data-astro-cid-n2ppamca>
Algunos de nuestros proyectos más recientes han reducido tiempos de operación en más de un 70%.
</p> </div> <div class="cases-grid" data-astro-cid-n2ppamca> <div class="case-card" data-astro-cid-n2ppamca> <div class="case-icon" data-astro-cid-n2ppamca>🧾</div> <h3 data-astro-cid-n2ppamca>Reportes Financieros</h3> <p data-astro-cid-n2ppamca>Automatización de reportes financieros semanales con datos en tiempo real</p> <div class="case-metric" data-astro-cid-n2ppamca>70% menos tiempo</div> </div> <div class="case-card" data-astro-cid-n2ppamca> <div class="case-icon" data-astro-cid-n2ppamca>📬</div> <h3 data-astro-cid-n2ppamca>Integración CRM</h3> <p data-astro-cid-n2ppamca>Conexión entre formulario web y CRM con envío automático de correos de seguimiento</p> <div class="case-metric" data-astro-cid-n2ppamca>0% errores manuales</div> </div> <div class="case-card" data-astro-cid-n2ppamca> <div class="case-icon" data-astro-cid-n2ppamca>🧠</div> <h3 data-astro-cid-n2ppamca>Chatbot Inteligente</h3> <p data-astro-cid-n2ppamca>Bot que responde preguntas frecuentes y genera leads calificados automáticamente</p> <div class="case-metric" data-astro-cid-n2ppamca>300% más leads</div> </div> </div> </div> </section>  ${renderComponent($$result3, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 600,
      height: 400,
      alt: "Automatizaci\xF3n empresarial inteligente"
    },
    title: "\u{1F3AF} \xBFListo para automatizar tu empresa?",
    paragraph: "Empieza hoy a reducir tareas manuales y aumentar tu eficiencia. Nuestro equipo dise\xF1a automatizaciones que se adaptan perfectamente a tu flujo de trabajo y transforman tu operaci\xF3n."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-n2ppamca": true })} ${renderComponent($$result3, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm", "data-astro-cid-n2ppamca": true })} ` })} </main> ${renderComponent($$result2, "Footer", Footer, { "data-astro-cid-n2ppamca": true })} ` })} `;
}, "/home/runner/work/website/website/src/pages/servicios/automatizaciones.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/servicios/automatizaciones.astro";
const $$url = "/servicios/automatizaciones";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Automatizaciones,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
