import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { T as Theme, M as MediaQuery, c as Container, F as FadeIn, $ as $$Layout, H as HeroSlider } from '../../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../../chunks/index_s5dUdJQS.mjs';
import { C as ContentSection } from '../../chunks/index_BoJW_L9D.mjs';
import { jsxs, jsx } from 'react/jsx-runtime';
import { useState, useEffect } from 'react';
import styled from '@emotion/styled';
import { F as Footer } from '../../chunks/index_BhCDT1zG.mjs';
import { P as ProcessStepper } from '../../chunks/index_CGmvxYTc.mjs';
import { C as ContactForm } from '../../chunks/index_DMYogpyB.mjs';
import { keyframes } from '@emotion/react';
export { renderers } from '../../renderers.mjs';

const HighlightBannerContainer = styled.section`
  background: ${Theme.primary};
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 50px;
    z-index: 1;
    position: relative;
`;
const GradientOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 1;
`;
const ContentWrapper = styled.div`
  position: relative;
  z-index: 2;
  text-align: center;
  max-width: 900px;
  margin: 0 auto;
`;
const TagLine = styled.p`
  color: ${Theme.tertiary};
  font-size: 14px;
  font-weight: 600;
  letter-spacing: 2px;
  text-transform: uppercase;
  margin-bottom: 20px;
  opacity: 0.9;

  ${MediaQuery.max("lg")} {
    font-size: 12px;
  }
`;
const MainText = styled.h2`
  color: ${Theme.tertiary};
  font-size: 48px;
  line-height: 1.2;
  font-weight: 700;
  margin: 0;
  text-align: center;

  ${MediaQuery.max("lg")} {
    font-size: 36px;
  }

  ${MediaQuery.max("md")} {
    font-size: 28px;
  }
`;

const HighlightBanner = ({
  tagline,
  mainText,
  variant = "default"
}) => {
  return /* @__PURE__ */ jsxs(HighlightBannerContainer, { variant, children: [
    /* @__PURE__ */ jsx(GradientOverlay, {}),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(ContentWrapper, { children: [
      tagline && /* @__PURE__ */ jsx(TagLine, { children: tagline }),
      /* @__PURE__ */ jsx(MainText, { children: mainText })
    ] }) }) })
  ] });
};

keyframes`
  0% {
    transform: translateY(0) scale(1);
  }
  100% {
    transform: translateY(-8px) scale(1.02);
  }
`;
const iconBounce = keyframes`
  0%, 20%, 60%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-10px);
  }
  80% {
    transform: translateY(-5px);
  }
`;
keyframes`
  0%, 100% {
    box-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
  }
  50% {
    box-shadow: 0 0 30px rgba(0, 212, 255, 0.6);
  }
`;
const slideInLeft = keyframes`
  from {
    opacity: 0;
    transform: translateX(-30px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
`;
const CardContainer = styled.div`
  display: flex;
  align-items: ${({ variant }) => variant === "horizontal" ? "center" : "flex-start"};
  flex-direction: ${({ variant }) => variant === "horizontal" ? "row" : "column"};
  gap: ${({ variant }) => variant === "horizontal" ? "20px" : "12px"};
  padding: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return "25px";
    case "checklist":
      return "20px";
    case "horizontal":
      return "20px";
    default:
      return "25px";
  }
}};
  background: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return Theme.secondary;
    case "checklist":
      return Theme.primary;
    case "horizontal":
      return Theme.secondary;
    default:
      return Theme.secondary;
  }
}};
  border-radius: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return "12px";
    case "checklist":
      return "10px";
    case "horizontal":
      return "16px";
    default:
      return "12px";
  }
}};
  border: ${({ variant }) => variant === "horizontal" ? `1px solid ${Theme.tertiary}` : "none"};
  text-align: ${({ variant }) => variant === "horizontal" ? "left" : "left"};
  cursor: ${({ onClick }) => onClick ? "pointer" : "default"};
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
  overflow: hidden;
  
  &:hover {
    transform: translateY(-6px);
    transition: transform 0.3s ease;
    ${({ variant }) => variant === "benefit" && `
      background: linear-gradient(135deg, ${Theme.secondary} 0%, ${Theme.tertiary} 100%);
    `}
    ${({ variant }) => variant === "horizontal" && `
      border-color: ${Theme.secondary};
      box-shadow: 0 8px 25px rgba(0, 212, 255, 0.15);
    `}
  }
  
  &:not(:hover) {
    transform: translateY(0);
    transition: transform 0.3s ease;
  }

  ${MediaQuery.max("lg")} {
    ${({ variant }) => variant === "horizontal" && `
      flex-direction: column;
      text-align: center;
      gap: 12px;
    `}
  }
`;
const IconContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: all 0.3s ease;
  
  ${({ variant, isHovered }) => variant === "checklist" && `
    width: 24px;
    height: 24px;
    background: ${Theme.tertiary};
    border-radius: 50%;
    margin-top: 2px;
    ${isHovered ? `animation: ${iconBounce} 0.6s ease-in-out;` : ""}
  `}
  
  ${({ variant, isHovered }) => variant === "benefit" && `
    margin-bottom: 5px;
    ${isHovered ? `animation: ${iconBounce} 0.6s ease-in-out;` : ""}
  `}
  
  ${({ variant, isHovered }) => variant === "horizontal" && `
    ${isHovered ? `animation: ${iconBounce} 0.6s ease-in-out;` : ""}
  `}
`;
const CheckIcon = styled.span`
  color: ${Theme.primary};
  font-weight: bold;
  font-size: 14px;
`;
const EmojiIcon = styled.span`
  font-size: ${({ variant }) => {
  switch (variant) {
    case "horizontal":
      return "48px";
    default:
      return "32px";
  }
}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.2);
  }
`;
const ContentContainer = styled.div`
  flex: 1;
  animation: ${slideInLeft} 0.6s ease-out;
`;
const Title = styled.h3`
  color: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return Theme.primary;
    case "checklist":
      return Theme.secondary;
    case "horizontal":
      return Theme.primary;
    default:
      return Theme.primary;
  }
}};
  font-size: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return "18px";
    case "checklist":
      return "16px";
    case "horizontal":
      return "16px";
    default:
      return "18px";
  }
}};
  margin-bottom: ${({ variant }) => variant === "checklist" ? "6px" : "8px"};
  font-weight: 600;
  transition: all 0.3s ease;
  
  ${({ isHovered, variant }) => isHovered && `
    transform: translateX(3px);
    color: ${variant === "checklist" ? Theme.tertiary : Theme.primary};
  `}
`;
const Description = styled.p`
  color: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return Theme.primary;
    case "checklist":
      return Theme.secondary;
    case "horizontal":
      return Theme.primary;
    default:
      return Theme.primary;
  }
}};
  margin: 0;
  opacity: ${({ variant }) => variant === "benefit" ? "0.8" : "0.8"};
  font-size: ${({ variant }) => {
  switch (variant) {
    case "benefit":
      return "14px";
    case "checklist":
      return "13px";
    case "horizontal":
      return "13px";
    default:
      return "14px";
  }
}};
  line-height: 1.4;
  transition: all 0.3s ease;
  
  &:hover {
    opacity: 1;
  }
`;

const AnimatedCard = ({
  icon,
  title,
  description,
  delay = 0,
  variant = "benefit",
  onClick
}) => {
  const [isHovered, setIsHovered] = useState(false);
  return /* @__PURE__ */ jsx(FadeIn, { delay, children: /* @__PURE__ */ jsxs(
    CardContainer,
    {
      variant,
      isHovered,
      onMouseEnter: () => setIsHovered(true),
      onMouseLeave: () => setIsHovered(false),
      onClick,
      role: onClick ? "button" : void 0,
      tabIndex: onClick ? 0 : void 0,
      children: [
        (variant === "checklist" || icon) && /* @__PURE__ */ jsx(IconContainer, { variant, isHovered, children: variant === "checklist" ? /* @__PURE__ */ jsx(CheckIcon, { children: "✓" }) : /* @__PURE__ */ jsx(EmojiIcon, { variant, children: icon }) }),
        /* @__PURE__ */ jsxs(ContentContainer, { variant, children: [
          /* @__PURE__ */ jsx(Title, { variant, isHovered, children: title }),
          /* @__PURE__ */ jsx(Description, { variant, children: description })
        ] })
      ]
    }
  ) });
};

keyframes`
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;
const SliderContainer = styled.div`
  position: relative;
  max-width: 800px;
  margin: 0 auto;
  overflow: hidden;
  
`;
const SliderWrapper = styled.div`
  display: flex;
  transition: transform 0.5s ease-in-out;
  transform: translateX(-${({ currentIndex }) => currentIndex * 100}%);
`;
const SlideItem = styled.div`
  min-width: 100%;
  display: flex;
  align-items: flex-start;
  gap: 20px;
  padding: 24px 32px;
  background: transparent;
  border: 1px solid ${Theme.tertiary}20;
  border-radius: 12px;
  box-sizing: border-box;
`;
const ItemTextContent = styled.div`
  wdth:auto;
  margin-left:30px;
`;
styled.span`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  background: ${Theme.tertiary};
  color: ${Theme.primary};
  border-radius: 50%;
  font-size: 14px;
  font-weight: bold;
  flex-shrink: 0;
  margin-top: 2px;
`;
const ItemContent = styled.div`
  flex: 1;
  display: flex;
  justify-content:center;
  align-items: center;
`;
const ItemTitle = styled.h4`
  color: ${Theme.tertiary};
  font-size: 38px;
  font-weight: 700 !important;
  margin: 0 0 4px 0 !important;
  line-height: 1.3;
`;
const ItemDescription = styled.p`
  color: ${Theme.tertiary};
  font-size: 15px;
  margin: 0;
  opacity: 0.8;
  line-height: 1.4;
`;
styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  margin-top: 24px;
`;
styled.button`
  background: ${({ disabled }) => disabled ? Theme.tertiary + "20" : Theme.tertiary};
  color: ${({ disabled }) => disabled ? Theme.tertiary + "40" : Theme.primary};
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: ${({ disabled }) => disabled ? "not-allowed" : "pointer"};
  transition: all 0.3s ease;
  font-size: 16px;
  font-weight: bold;

  &:hover:not(:disabled) {
    background: ${Theme.tertiary};
    transform: scale(1.1);
  }
`;
const DotsContainer = styled.div`
  display: flex;
  justify-content:center;
  gap: 8px;
`;
const Dot = styled.button`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: none;
  background-color: ${(props) => props.active ? Theme.tertiary : "rgba(0, 0, 0, 0.3)"};
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: ${(props) => props.active ? Theme.tertiary : "rgba(0, 0, 0, 0.5)"};
    transform: scale(1.1);
  }
`;
const CompactChecklist = ({
  items,
  delay = 0,
  autoPlay = true,
  autoPlayInterval = 4e3
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  useEffect(() => {
    if (!autoPlay || items.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex(
        (prevIndex) => prevIndex === items.length - 1 ? 0 : prevIndex + 1
      );
    }, autoPlayInterval);
    return () => clearInterval(interval);
  }, [autoPlay, autoPlayInterval, items.length]);
  const goToSlide = (index) => {
    setCurrentIndex(index);
  };
  return /* @__PURE__ */ jsx(FadeIn, { delay, children: /* @__PURE__ */ jsxs(SliderContainer, { children: [
    /* @__PURE__ */ jsx(SliderWrapper, { currentIndex, totalItems: items.length, children: items.map((item, index) => /* @__PURE__ */ jsx(SlideItem, { children: /* @__PURE__ */ jsx(ItemContent, { children: /* @__PURE__ */ jsxs(ItemTextContent, { children: [
      /* @__PURE__ */ jsx(ItemTitle, { children: item.title }),
      /* @__PURE__ */ jsx(ItemDescription, { children: item.description })
    ] }) }) }, index)) }),
    /* @__PURE__ */ jsx(DotsContainer, { children: items.map((_, index) => /* @__PURE__ */ jsx(
      Dot,
      {
        active: index === currentIndex,
        onClick: () => goToSlide(index),
        "aria-label": `Ir al slide ${index + 1}`
      },
      index
    )) })
  ] }) });
};

const $$SitioWebExpress = createComponent(($$result, $$props, $$slots) => {
  const seoTitle = "Sitios Web Express | Luxion";
  const seoDescription = "Creamos sitios web modernos y administrables en tiempo r\xE9cord, con IA que optimiza el desarrollo. Landing pages en el mismo d\xEDa y costos m\xEDnimos.";
  const benefits = [
    {
      title: "\u{1F680} Entrega ultra r\xE1pida",
      description: "Sitios web en 48 horas, landing pages el mismo d\xEDa"
    },
    {
      title: "\u{1F916} Desarrollo asistido por IA",
      description: "Flujos optimizados, contenido y estructura generados con precisi\xF3n"
    },
    {
      title: "\u{1F9ED} Administrable con Markdown",
      description: "Edita f\xE1cilmente textos e im\xE1genes sin depender de terceros"
    },
    {
      title: "\u{1F3A8} Dise\xF1o adaptable",
      description: "Moderno, minimalista y funcional en todos los dispositivos"
    },
    {
      title: "\u{1F4B0} Costo reducido",
      description: "Gracias a la automatizaci\xF3n, pagas menos sin sacrificar calidad"
    },
    {
      title: "\u{1F4C8} Optimizaci\xF3n SEO autom\xE1tica",
      description: "Tu sitio listo para posicionarse desde el primer d\xEDa"
    }
  ];
  const includes = [
    {
      title: "\u2713 Hasta 5 secciones completas",
      description: "Inicio, Servicios, Nosotros, Contacto, etc."
    },
    {
      title: "\u2713 Formularios funcionales y enlaces a redes sociales",
      description: "Contacto y conexi\xF3n social integrados"
    },
    {
      title: "\u2713 Integraci\xF3n con Google Analytics y Mapas",
      description: "An\xE1lisis y ubicaci\xF3n configurados"
    },
    {
      title: "\u2713 Textos optimizados por IA seg\xFAn tu negocio",
      description: "Contenido personalizado y optimizado"
    },
    {
      title: "\u2713 Hosting y dominio opcional para lanzamiento inmediato",
      description: "Todo listo para publicar"
    },
    {
      title: "\u2713 Panel de contenido en Markdown (.md) editable",
      description: "F\xE1cil edici\xF3n sin conocimientos t\xE9cnicos"
    }
  ];
  const processSteps = [
    {
      number: "1",
      title: "Brief r\xE1pido",
      description: "Cu\xE9ntanos tu negocio y el tipo de sitio que deseas"
    },
    {
      number: "2",
      title: "Generaci\xF3n IA + dise\xF1o",
      description: "Nuestra IA crea estructura, textos e im\xE1genes optimizadas"
    },
    {
      number: "3",
      title: "Revisi\xF3n y entrega",
      description: "Te entregamos el sitio listo para publicar en menos de 48h"
    }
  ];
  const perfectFor = [
    {
      icon: "",
      title: "Mostrar tus servicios profesionales",
      description: "Presencia profesional para tu negocio"
    },
    {
      icon: "",
      title: "Dar presencia online a tu empresa o startup",
      description: "Establecer tu marca en el mundo digital"
    },
    {
      icon: "",
      title: "Promocionar productos o campa\xF1as espec\xEDficas",
      description: "Marketing efectivo para tus productos"
    },
    {
      icon: "",
      title: "Tener una landing page lista para anuncios o lanzamientos",
      description: "Conversi\xF3n optimizada desde el primer d\xEDa"
    },
    {
      icon: "",
      title: "Probar ideas digitales sin grandes inversiones",
      description: "Validar conceptos con m\xEDnimo riesgo"
    }
  ];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": seoTitle, "description": seoDescription }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Sitios web express impulsados por IA, listos en horas, no semanas",
      paragraph: "En Luxion, combinamos dise\xF1o moderno con el poder de la Inteligencia Artificial para crear sitios web express que se desarrollan en una fracci\xF3n del tiempo tradicional. Lanza tu presencia digital con un sitio administrable, veloz y optimizado, listo en menos de 48 horas, o una landing page profesional en el mismo d\xEDa."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Container", Container, {}, { "default": ($$result3) => renderTemplate`  ${renderComponent($$result3, "HighlightBanner", HighlightBanner, { "tagline": "TECNOLOG\xCDA AVANZADA", "mainText": "\u26A1\u{1F916} IA + experiencia = tu sitio web en tiempo r\xE9cord y al menor costo.", "variant": "gradient", "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@modules/HighlightBanner", "client:component-export": "HighlightBanner" })}  ${renderComponent($$result3, "ContentSection", ContentSection, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@modules/ContentSection", "client:component-export": "ContentSection" }, { "default": ($$result4) => renderTemplate` <div style="text-align: center; margin-bottom: 60px;"> <p style="color: var(--secondary); font-size: 14px; font-weight: 600; letter-spacing: 2px; margin-bottom: 20px; text-transform: uppercase;">BENEFICIOS CLAVE</p> <h2 style="color: var(--tertiary);">¿Por qué elegir nuestro servicio express con IA?</h2> </div> <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 40px; max-width: 1000px; margin: 0 auto;"> ${benefits.map((benefit, index) => renderTemplate`${renderComponent($$result4, "AnimatedCard", AnimatedCard, { "icon": benefit.title.split(" ")[0], "title": benefit.title.substring(benefit.title.indexOf(" ") + 1), "description": benefit.description, "variant": "benefit", "delay": index * 100, "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/AnimatedCard", "client:component-export": "AnimatedCard" })}`)} </div> ` })}  <section style="background: var(--secondary); padding: 100px 0; margin: 50px 0;"> <div style="max-width: 1200px; margin: 0 auto; padding: 0 20px;"> <div style="text-align: center; margin-bottom: 60px;"> <p style="color: var(--primary); font-size: 14px; font-weight: 600; letter-spacing: 2px; margin-bottom: 20px; text-transform: uppercase;">TODO LO QUE INCLUYE</p> <h2 style="color: var(--primary);">Todo lo que recibes</h2> </div> <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px; max-width: 800px; margin: 0 auto;"> ${includes.map((include, index) => renderTemplate`${renderComponent($$result3, "AnimatedCard", AnimatedCard, { "icon": "\u2713", "title": include.title.substring(2), "description": include.description, "variant": "checklist", "delay": index * 150, "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/AnimatedCard", "client:component-export": "AnimatedCard" })}`)} </div> </div> </section> ${renderComponent($$result3, "ProcessStepper", ProcessStepper, { "subtitle": "PROCESO OPTIMIZADO", "title": "As\xED aceleramos tu lanzamiento", "client:visible": true, "steps": processSteps, "client:component-hydration": "visible", "client:component-path": "@components/ProcessStepper", "client:component-export": "ProcessStepper" })}  <section style="background: #f4f4f4;"> ${renderComponent($$result3, "ContentSection", ContentSection, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@modules/ContentSection", "client:component-export": "ContentSection" }, { "default": ($$result4) => renderTemplate` <div style="text-align: center; margin-bottom: 30px;"> <p style="color: var(--secondary); font-size: 12px; font-weight: 600; letter-spacing: 1.5px; margin-bottom: 12px; text-transform: uppercase;">CASOS DE USO</p> <h2 style="font-size: 32px; line-height: 1.2; margin-bottom: 0; color: var(--secondary);">Perfecto si necesitas…</h2> </div> <div style="display: flex; flex-direction: column; gap: 40px; margin-top: 40px;"> ${renderComponent($$result4, "CompactChecklist", CompactChecklist, { "items": perfectFor.map((item) => ({
    title: item.title,
    description: item.description
  })), "delay": 200, "client:load": true, "client:component-hydration": "load", "client:component-path": "@components/CompactChecklist", "client:component-export": "CompactChecklist" })} </div> ` })} </section> ${renderComponent($$result3, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: HeroSlider.src,
      width: 600,
      height: 400,
      alt: "Sitio web express con IA"
    },
    title: "\u{1F680} Lanza tu web hoy mismo",
    paragraph: "Con Luxion, obtienes sitios express impulsados por IA, listos en horas y con costos m\xEDnimos. Solicita tu web express ahora y obt\xE9n tu landing page el mismo d\xEDa."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result3, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm" })} ` })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/home/runner/work/website/website/src/pages/servicios/sitio-web-express.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/servicios/sitio-web-express.astro";
const $$url = "/servicios/sitio-web-express";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$SitioWebExpress,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
