import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout, H as HeroSlider, c as Container, I as InfiniteImg1 } from '../../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../../chunks/index_s5dUdJQS.mjs';
import { S as ServiceCards } from '../../chunks/index_CMV_vsGS.mjs';
import { F as Footer } from '../../chunks/index_BhCDT1zG.mjs';
import { P as ProcessStepper } from '../../chunks/index_CGmvxYTc.mjs';
import { C as ContactForm } from '../../chunks/index_DMYogpyB.mjs';
import 'react/jsx-runtime';
import 'react';
export { renderers } from '../../renderers.mjs';

const $$Soporte = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Soporte WordPress y mantenimiento web | Luxion", "description": "Brindamos soporte t\xE9cnico y mantenimiento continuo para tu sitio o sistema, asegurando seguridad, velocidad y disponibilidad sin interrupciones." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> <!-- Hero Principal --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Soporte t\xE9cnico y mantenimiento digital sin complicaciones",
      paragraph: "En Luxion, nos encargamos de mantener tu sitio web o sistema siempre seguro, r\xE1pido y actualizado. Monitoreamos su rendimiento, aplicamos parches de seguridad, realizamos copias de seguridad autom\xE1ticas y solucionamos cualquier incidencia t\xE9cnica antes de que afecte a tus usuarios. T\xFA te concentras en tu negocio, nosotros cuidamos tu tecnolog\xEDa."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Container", Container, {}, { "default": ($$result3) => renderTemplate`  ${renderComponent($$result3, "ServiceCards", ServiceCards, { "description": "SOPORTE INTEGRAL", "title": "Todo lo que incluye nuestro servicio", "client:visible": true, "cards": [
    {
      title: "\u{1F504} Mantenimiento continuo",
      description: "Revisiones programadas y actualizaciones autom\xE1ticas para mantener tu sitio siempre al d\xEDa."
    },
    {
      title: "\u{1F41E} Reparaci\xF3n de errores",
      description: "Diagn\xF3stico y correcci\xF3n r\xE1pida de fallos o conflictos antes de que afecten a tus usuarios."
    },
    {
      title: "\u26A1 Optimizaci\xF3n de rendimiento",
      description: "Mejora de velocidad, optimizaci\xF3n de base de datos y configuraci\xF3n de cach\xE9 avanzado."
    },
    {
      title: "\u{1F9F1} Seguridad avanzada",
      description: "Eliminaci\xF3n de malware y protecci\xF3n activa 24/7 contra amenazas y vulnerabilidades."
    },
    {
      title: "\u2601\uFE0F Copias de seguridad autom\xE1ticas",
      description: "Resguardo semanal o diario seg\xFAn tu plan, con restauraci\xF3n r\xE1pida cuando sea necesario."
    },
    {
      title: "\u{1F4AC} Soporte t\xE9cnico personalizado",
      description: "Canales directos para asistencia inmediata con nuestro equipo de expertos t\xE9cnicos."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })}  ${renderComponent($$result3, "ServiceCards", ServiceCards, { "description": "SOLUCIONES PERSONALIZADAS", "title": "Soluciones adaptadas a tu necesidad", "client:visible": true, "cards": [
    {
      title: "\u{1F310} Webs informativas",
      description: "Actualizaci\xF3n de plugins, seguridad y contenido para sitios corporativos y p\xE1ginas informativas."
    },
    {
      title: "\u{1F6D2} E-commerce y WordPress avanzados",
      description: "Soporte integral para WooCommerce, pasarelas de pago y funcionalidades complejas."
    },
    {
      title: "\u2699\uFE0F Aplicaciones personalizadas o SaaS",
      description: "Monitoreo de uptime, an\xE1lisis de logs y backups de bases de datos para sistemas complejos."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })}  ${renderComponent($$result3, "ProcessStepper", ProcessStepper, { "client:visible": true, "title": "\u{1F6E0}\uFE0F Nuestro proceso de soporte", "subtitle": "METODOLOG\xCDA PROBADA", "description": "Seguimos un proceso estructurado para mantener tu sitio web o sistema siempre operativo y seguro.", "steps": [
    {
      number: "1",
      title: "Diagn\xF3stico inicial",
      description: "Analizamos tu sitio o sistema para identificar posibles mejoras y vulnerabilidades."
    },
    {
      number: "2",
      title: "Plan de mantenimiento",
      description: "Creamos un plan personalizado con tareas programadas y protocolos de seguridad."
    },
    {
      number: "3",
      title: "Monitoreo continuo",
      description: "Supervisamos el rendimiento 24/7 y aplicamos actualizaciones de forma proactiva."
    },
    {
      number: "4",
      title: "Soporte reactivo",
      description: "Respondemos r\xE1pidamente a incidencias y problemas t\xE9cnicos cuando surgen."
    },
    {
      number: "5",
      title: "Reportes y optimizaci\xF3n",
      description: "Proporcionamos informes regulares y optimizamos continuamente el rendimiento."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@components/ProcessStepper", "client:component-export": "ProcessStepper" })}  ${renderComponent($$result3, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 600,
      height: 400,
      alt: "Equipo t\xE9cnico brindando soporte y mantenimiento web"
    },
    title: "\u{1F527} Mant\xE9n tu sitio funcionando al 100%",
    paragraph: "Evita ca\xEDdas, lentitud o problemas de seguridad. Conf\xEDa en Luxion para mantener tu sistema siempre operativo. Nuestro equipo de expertos est\xE1 listo para brindar el soporte que necesitas."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result3, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm" })} ` })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/home/runner/work/website/website/src/pages/servicios/soporte.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/servicios/soporte.astro";
const $$url = "/servicios/soporte";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Soporte,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
