import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { $ as $$Layout, H as HeroSlider } from '../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../chunks/index_s5dUdJQS.mjs';
import { F as Footer } from '../chunks/index_BhCDT1zG.mjs';
import { C as ContactForm } from '../chunks/index_DMYogpyB.mjs';
export { renderers } from '../renderers.mjs';

const $$Contacto = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Contacto | Luxion", "description": "\xA1Cont\xE1ctanos y te ayudaremos!" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:load": true, "data": {
    image: HeroSlider.src,
    content: {
      title: "Contacto",
      paragraph: "\xA1Cont\xE1ctanos y te ayudaremos!"
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ContactForm", ContactForm, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@components/ContactForm", "client:component-export": "ContactForm" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/home/runner/work/website/website/src/pages/contacto.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/contacto.astro";
const $$url = "/contacto";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Contacto,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
