import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout } from '../chunks/index_B3DN2MbO.mjs';
import { H as Hero } from '../chunks/index_s5dUdJQS.mjs';
export { renderers } from '../renderers.mjs';

const HeroSliderVideo1 = "/_astro/hero-slider-01.C3ZlyUDI.mp4";

const HeroSliderVideo2 = "/_astro/hero-slider-02.piUiAvGd.mp4";

const HeroSliderVideo3 = "/_astro/hero-slider-03.s2cDBXxT.mp4";

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Luxion | Desarrollo de software y automatizaciones inteligentes", "description": "Dise\xF1amos software, sitios web y automatizaciones que optimizan tus procesos y potencian tu negocio con tecnolog\xEDa sin complicaciones." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "Qu\xE9 hacemos",
      title: "Impulsamos tu negocio con tecnolog\xEDa inteligente",
      background: HeroSliderVideo1,
      paragraph: "En Luxion desarrollamos software, sitios web y automatizaciones a medida que optimizan procesos, reducen costos y simplifican la gesti\xF3n digital de tu empresa.",
      button: {
        text: "Descubre nuestras soluciones",
        link: "/software-a-medida"
      }
    },
    {
      subtitle: "Automatizaciones inteligentes",
      title: "Automatiza tareas, enf\xF3cate en lo importante",
      background: HeroSliderVideo2,
      paragraph: "Dise\xF1amos flujos automatizados que integran tus sistemas y eliminan procesos repetitivos. Desde bots hasta integraciones entre plataformas, hacemos que la tecnolog\xEDa trabaje por ti.",
      button: {
        text: "Ver servicios de automatizaci\xF3n",
        link: "/automatizaciones"
      }
    },
    {
      subtitle: "Desarrollo express",
      title: "Sitios web informativos listos en tiempo r\xE9cord",
      background: HeroSliderVideo3,
      paragraph: "Con nuestro servicio Express Web, obt\xE9n una p\xE1gina moderna, administrable y optimizada en pocos d\xEDas, con costos m\xEDnimos y alto impacto visual. Ideal para pymes y profesionales.",
      button: {
        text: "Cotiza tu web express",
        link: "/sitios-web-express"
      }
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "/home/runner/work/website/website/src/pages/index.astro", void 0);

const $$file = "/home/runner/work/website/website/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
